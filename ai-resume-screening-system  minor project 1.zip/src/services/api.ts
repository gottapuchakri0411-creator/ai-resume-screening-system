import {
  User,
  Job,
  Candidate,
  Resume,
  ScreeningResult,
  RankedCandidate,
  CandidateNote,
  AnalyticsData
} from '../types';

const TOKEN_KEY = 'ai_resume_screener_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string | null): void {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string> || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  if (!(options.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || `HTTP error ${response.status}: ${response.statusText}`);
  }

  return data as T;
}

export const api = {
  // Authentication
  async register(payload: { name: string; email: string; password: string; company?: string; role?: string }) {
    const data = await request<{ user: User; token: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    setStoredToken(data.token);
    return data;
  },

  async login(payload: { email: string; password: string }) {
    const data = await request<{ user: User; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    setStoredToken(data.token);
    return data;
  },

  async getMe() {
    return request<{ user: User }>('/api/auth/me');
  },

  logout() {
    setStoredToken(null);
  },

  // Jobs
  async getJobs() {
    return request<{ jobs: Job[] }>('/api/jobs');
  },

  async getJobById(id: string) {
    return request<{ job: Job; resumes: Resume[]; screeningResults: ScreeningResult[] }>(`/api/jobs/${id}`);
  },

  async createJob(jobData: Partial<Job>) {
    return request<{ job: Job }>('/api/jobs', {
      method: 'POST',
      body: JSON.stringify(jobData),
    });
  },

  async updateJob(id: string, updates: Partial<Job>) {
    return request<{ job: Job }>(`/api/jobs/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async deleteJob(id: string) {
    return request<{ message: string }>(`/api/jobs/${id}`, {
      method: 'DELETE',
    });
  },

  // Resumes
  async uploadResumes(jobId: string, files: File[]) {
    const formData = new FormData();
    files.forEach(file => {
      formData.append('resumes', file);
    });

    return request<{ message: string; resumes: Resume[]; errors?: { filename: string; error: string }[] }>(
      `/api/jobs/${jobId}/resumes`,
      {
        method: 'POST',
        body: formData,
      }
    );
  },

  async deleteResume(id: string) {
    return request<{ message: string }>(`/api/resumes/${id}`, {
      method: 'DELETE',
    });
  },

  // Screening
  async triggerScreening(jobId: string, resumeIds?: string[]) {
    return request<{ message: string; results: ScreeningResult[]; failures?: any[] }>(`/api/screen/${jobId}`, {
      method: 'POST',
      body: JSON.stringify({ resumeIds }),
    });
  },

  async getScreeningResults(jobId: string) {
    return request<{ job: Job; rankedCandidates: RankedCandidate[] }>(`/api/screen/${jobId}`);
  },

  async updateCandidateStatus(screeningId: string, status: ScreeningResult['status']) {
    return request<{ screeningResult: ScreeningResult }>(`/api/screen/${screeningId}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
  },

  // Candidates
  async getCandidates() {
    return request<{ candidates: Candidate[] }>('/api/candidates');
  },

  async getCandidateDetails(id: string) {
    return request<{
      candidate: Candidate;
      screening?: ScreeningResult;
      job?: Job;
      resume?: Resume;
      notes: CandidateNote[];
    }>(`/api/candidates/${id}`);
  },

  async addNote(candidateId: string, content: string, jobId?: string) {
    return request<{ note: CandidateNote }>(`/api/candidates/${candidateId}/notes`, {
      method: 'POST',
      body: JSON.stringify({ content, jobId }),
    });
  },

  async createNote(candidateId: string, content: string, jobId?: string) {
    return this.addNote(candidateId, content, jobId);
  },

  async updateNote(noteId: string, content: string) {
    return request<{ note: CandidateNote }>(`/api/notes/${noteId}`, {
      method: 'PUT',
      body: JSON.stringify({ content }),
    });
  },

  async deleteNote(noteId: string) {
    return request<{ message: string }>(`/api/notes/${noteId}`, {
      method: 'DELETE',
    });
  },

  // Analytics
  async getAnalytics() {
    return request<{ analytics: AnalyticsData }>('/api/analytics');
  },

  // Health
  async checkHealth() {
    return request<{ status: string; geminiConfigured: boolean }>('/api/health');
  },

  // Recruiter Copilot & Audio Transcription
  async sendCopilotMessage(payload: {
    messages: { role: 'user' | 'model'; content: string }[];
    candidateId?: string;
    jobId?: string;
    useSearch?: boolean;
    modelSpeed?: 'fast' | 'general' | 'deep';
  }) {
    return request<{
      reply: string;
      searchSources?: { title?: string; uri?: string }[];
    }>('/api/copilot/chat', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  },

  async transcribeAudio(audioBlob: Blob) {
    const formData = new FormData();
    formData.append('audio', audioBlob, 'recruiter_voice_note.webm');

    return request<{ transcription: string }>('/api/copilot/transcribe', {
      method: 'POST',
      body: formData,
    });
  },

  // Lyria Music Generation
  async generateMusic(prompt: string, trackType: 'clip' | 'pro' = 'clip') {
    return request<{
      success: boolean;
      audioBase64: string;
      mimeType: string;
      lyrics?: string;
      modelUsed: string;
      trackType: string;
      prompt: string;
      generatedAt: string;
    }>('/api/music/generate', {
      method: 'POST',
      body: JSON.stringify({ prompt, trackType }),
    });
  }
};


import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Briefcase,
  Users,
  FileText,
  CheckCircle2,
  AlertTriangle,
  Award,
  TrendingUp,
  Plus,
  ArrowRight,
  Sparkles,
  Loader2,
  FolderOpen
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { api } from '../services/api';
import { AnalyticsData, Job } from '../types';
import { ScoreBadge, StatusBadge } from '../components/ScoreBadge';
import { ResponsibleAIBanner } from '../components/ResponsibleAIBanner';
import { EmptyState } from '../components/EmptyState';

const SCORE_COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#f97316', '#ef4444'];

export const DashboardPage: React.FC = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const [analyticsRes, jobsRes] = await Promise.all([
        api.getAnalytics(),
        api.getJobs()
      ]);
      setAnalytics(analyticsRes.analytics);
      setJobs(jobsRes.jobs);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="py-24 flex flex-col items-center justify-center gap-3">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
        <p className="text-sm text-slate-500 font-medium">Loading recruiter dashboard data...</p>
      </div>
    );
  }

  const hasData = analytics && (analytics.totalJobs > 0 || analytics.totalResumes > 0);

  return (
    <div className="space-y-6">
      <ResponsibleAIBanner />

      {/* Top Welcome & Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Talent Screening Overview</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time screening metrics, applicant score distributions, and NLP analysis
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => navigate('/jobs/create')}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-xs shadow-indigo-600/30 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Create New Job</span>
          </button>
        </div>
      </div>

      {!hasData ? (
        <EmptyState
          icon={FolderOpen}
          title="No Screening Data Available Yet"
          description="Get started by posting your first job description, then upload candidate resumes to trigger automated NLP screening."
          actionText="Create First Job"
          onAction={() => navigate('/jobs/create')}
        />
      ) : (
        <>
          {/* Key Metric Cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Total Jobs</span>
                <Briefcase className="w-4 h-4 text-indigo-500" />
              </div>
              <div className="text-2xl font-black text-slate-900">{analytics.totalJobs}</div>
              <div className="text-[11px] text-emerald-600 font-medium mt-1">
                {analytics.activeJobs} active postings
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Resumes</span>
                <FileText className="w-4 h-4 text-blue-500" />
              </div>
              <div className="text-2xl font-black text-slate-900">{analytics.totalResumes}</div>
              <div className="text-[11px] text-slate-500 font-medium mt-1">
                {analytics.processedResumes} screened
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Candidates</span>
                <Users className="w-4 h-4 text-purple-500" />
              </div>
              <div className="text-2xl font-black text-slate-900">{analytics.totalCandidates}</div>
              <div className="text-[11px] text-slate-500 font-medium mt-1">
                Across {analytics.totalJobs} pipelines
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Avg Match</span>
                <Award className="w-4 h-4 text-emerald-500" />
              </div>
              <div className="text-2xl font-black text-emerald-600">{analytics.averageMatchScore}%</div>
              <div className="text-[11px] text-slate-500 font-medium mt-1">
                Semantic relevance
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Review Queue</span>
                <AlertTriangle className="w-4 h-4 text-amber-500" />
              </div>
              <div className="text-2xl font-black text-amber-600">{analytics.candidatesRequiringReview}</div>
              <div className="text-[11px] text-slate-500 font-medium mt-1">
                Pending decision
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">NLP Accuracy</span>
                <Sparkles className="w-4 h-4 text-indigo-500" />
              </div>
              <div className="text-2xl font-black text-indigo-600">TF-IDF</div>
              <div className="text-[11px] text-slate-500 font-medium mt-1">
                Cosine + Gemini 3.8
              </div>
            </div>
          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Score Distribution Chart */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Match Score Distribution</h3>
                  <p className="text-xs text-slate-500">Candidate ranking tiers across all job postings</p>
                </div>
                <TrendingUp className="w-4 h-4 text-slate-400" />
              </div>

              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={analytics.scoreDistribution} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="range" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} allowDecimals={false} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                      itemStyle={{ color: '#818cf8' }}
                    />
                    <Bar dataKey="count" fill="#4f46e5" radius={[6, 6, 0, 0]}>
                      {analytics.scoreDistribution.map((_entry, index) => (
                        <Cell key={`cell-${index}`} fill={SCORE_COLORS[index % SCORE_COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Candidates Per Job Chart */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Applicant Intake per Job</h3>
                  <p className="text-xs text-slate-500">Screened candidate volume by position</p>
                </div>
                <Briefcase className="w-4 h-4 text-slate-400" />
              </div>

              {analytics.candidatesPerJob.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-xs text-slate-400">
                  No applicants registered yet.
                </div>
              ) : (
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analytics.candidatesPerJob} layout="vertical" margin={{ top: 10, right: 20, left: 10, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                      <XAxis type="number" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} allowDecimals={false} />
                      <YAxis dataKey="jobTitle" type="category" width={110} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                      />
                      <Bar dataKey="count" fill="#6366f1" radius={[0, 6, 6, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          </div>

          {/* Active Jobs & Recent Activity Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Active Jobs Table (2 cols) */}
            <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="p-5 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Active Job Pipelines</h3>
                  <p className="text-xs text-slate-500">Select a position to view candidates or upload resumes</p>
                </div>
                <Link
                  to="/jobs"
                  className="text-xs text-indigo-600 hover:text-indigo-700 font-semibold inline-flex items-center gap-1"
                >
                  <span>View all jobs</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>

              <div className="divide-y divide-slate-100">
                {jobs.slice(0, 4).map(job => (
                  <div key={job.id} className="p-4 hover:bg-slate-50/80 transition-colors flex items-center justify-between gap-4">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Link to={`/jobs/${job.id}`} className="text-sm font-bold text-slate-900 hover:text-indigo-600 truncate">
                          {job.title}
                        </Link>
                        <StatusBadge status={job.status} />
                      </div>
                      <div className="flex flex-wrap items-center gap-y-1 gap-x-3 text-xs text-slate-500">
                        <span>{job.department}</span>
                        <span>•</span>
                        <span>{job.location}</span>
                        <span>•</span>
                        <span>{job.requiredSkills.slice(0, 3).join(', ')}{job.requiredSkills.length > 3 ? ` +${job.requiredSkills.length - 3}` : ''}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <Link
                        to={`/screening/${job.id}`}
                        className="px-3 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold transition-colors flex items-center gap-1.5"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Screening</span>
                      </Link>
                      <Link
                        to={`/jobs/${job.id}`}
                        className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-semibold transition-colors"
                      >
                        Details
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Top Matched Skills Column (1 col) */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col">
              <div className="mb-4">
                <h3 className="text-sm font-bold text-slate-900">Dominant Candidate Skills</h3>
                <p className="text-xs text-slate-500">Most verified competencies extracted from resumes</p>
              </div>

              {analytics.topSkills.length === 0 ? (
                <div className="flex-1 flex items-center justify-center text-xs text-slate-400">
                  No skills extracted yet.
                </div>
              ) : (
                <div className="space-y-2.5 flex-1">
                  {analytics.topSkills.map((skill, i) => (
                    <div key={skill.name} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="w-5 h-5 rounded-md bg-slate-100 text-slate-600 font-bold flex items-center justify-center text-[10px] shrink-0">
                          {i + 1}
                        </span>
                        <span className="font-semibold text-slate-800 truncate">{skill.name}</span>
                      </div>
                      <span className="px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 font-bold shrink-0">
                        {skill.count} {skill.count === 1 ? 'match' : 'matches'}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-4 pt-4 border-t border-slate-100 text-[11px] text-slate-400">
                Skills normalized via canonical dictionary (e.g. JS &rarr; JavaScript)
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  MicOff,
  Music,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Download,
  Copy,
  Check,
  Sparkles,
  Loader2,
  FileAudio,
  Radio,
  Sliders,
  RefreshCw,
  Plus,
  Send,
  User,
  Briefcase,
  Headphones,
  Info,
  Clock,
  Trash2,
  AlertCircle
} from 'lucide-react';
import { api } from '../services/api';
import { useToast } from '../components/Toast';
import { Job, Candidate } from '../types';

interface GeneratedTrack {
  id: string;
  title: string;
  prompt: string;
  trackType: 'clip' | 'pro';
  modelUsed: string;
  audioUrl: string;
  mimeType: string;
  lyrics?: string;
  generatedAt: string;
}

interface SavedTranscription {
  id: string;
  text: string;
  purpose: string;
  candidateName?: string;
  jobTitle?: string;
  timestamp: string;
  durationSeconds?: number;
}

export const AudioStudioPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'transcribe' | 'music'>('transcribe');
  const { showToast } = useToast();

  // Jobs and candidates for context linking
  const [jobs, setJobs] = useState<Job[]>([]);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [selectedJobId, setSelectedJobId] = useState<string>('');
  const [selectedCandidateId, setSelectedCandidateId] = useState<string>('');

  // ----------------------------------------------------------------------
  // 1. AUDIO RECORDING & TRANSCRIPTION (gemini-3.5-transcribe)
  // ----------------------------------------------------------------------
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [isTranscribing, setIsTranscribing] = useState<boolean>(false);
  const [transcriptionText, setTranscriptionText] = useState<string>('');
  const [transcriptionPurpose, setTranscriptionPurpose] = useState<string>('Interview Debrief');
  const [transcriptionHistory, setTranscriptionHistory] = useState<SavedTranscription[]>([]);
  const [copiedTranscription, setCopiedTranscription] = useState<boolean>(false);
  const [savingAsNote, setSavingAsNote] = useState<boolean>(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<any>(null);

  // ----------------------------------------------------------------------
  // 2. LYRIA MUSIC GENERATION (lyria-3-clip-preview & lyria-3-pro-preview)
  // ----------------------------------------------------------------------
  const [musicPrompt, setMusicPrompt] = useState<string>(
    'Deep focus chill lo-fi hip hop beat with warm rhodes piano, subtle vinyl crackle, and steady downtempo rhythm for reviewing candidate resumes'
  );
  const [trackType, setTrackType] = useState<'clip' | 'pro'>('clip');
  const [isGeneratingMusic, setIsGeneratingMusic] = useState<boolean>(false);
  const [generatedTracks, setGeneratedTracks] = useState<GeneratedTrack[]>([]);
  const [activeTrack, setActiveTrack] = useState<GeneratedTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(0.85);

  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  // Curated prompts for recruiters
  const promptPresets = [
    {
      title: 'Deep Focus Lo-Fi',
      desc: '30s chill downtempo with Rhodes keys for resume screening',
      type: 'clip' as const,
      prompt: 'Deep focus chill lo-fi hip hop beat with warm rhodes piano, subtle vinyl crackle, and steady downtempo rhythm for reviewing candidate resumes'
    },
    {
      title: 'Tech Culture Anthem',
      desc: 'Full-length uplifting synthesizer anthem for career fair reels',
      type: 'pro' as const,
      prompt: 'Inspiring modern corporate tech anthem with energetic synth arpeggios, driving drums, and uplifting optimism for engineering hiring campaigns'
    },
    {
      title: 'Acoustic Interview Piano',
      desc: '30s peaceful piano and cello for interview evaluation debriefs',
      type: 'clip' as const,
      prompt: 'Gentle ambient classical piano and warm cello acoustic melody for reflective candidate interviews and evaluation debriefs'
    },
    {
      title: 'Hackathon Cyber Beat',
      desc: 'Fast energetic electronic rhythm for tech challenges',
      type: 'pro' as const,
      prompt: 'Energetic cyberpunk electronic synthwave rhythm with punchy bass and bright arpeggios for high-velocity technical screening and coding challenges'
    },
    {
      title: 'Binaural Screening Flow',
      desc: 'Ambient harmonic undertones for calm concentration',
      type: 'clip' as const,
      prompt: 'Subtle atmospheric ambient drone with warm 432Hz harmonic undertones and light pads for calm, unbiased hiring concentration'
    }
  ];

  // Fetch initial context (jobs, candidates)
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [jobsRes, candRes] = await Promise.all([
          api.getJobs(),
          api.getCandidates()
        ]);
        if (jobsRes && jobsRes.jobs) setJobs(jobsRes.jobs);
        if (candRes && candRes.candidates) setCandidates(candRes.candidates);
      } catch (err) {
        console.error('Failed to load jobs or candidates for context linking', err);
      }
    };
    fetchData();
  }, []);

  // Cleanup timer on unmount
  useEffect(() => {
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if (recordedAudioUrl) URL.revokeObjectURL(recordedAudioUrl);
    };
  }, [recordedAudioUrl]);

  // Handle audio player events
  useEffect(() => {
    const audio = audioPlayerRef.current;
    if (!audio) return;

    const onTimeUpdate = () => setCurrentTime(audio.currentTime);
    const onLoadedMetadata = () => setDuration(audio.duration || 0);
    const onEnded = () => setIsPlaying(false);

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('ended', onEnded);

    return () => {
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('ended', onEnded);
    };
  }, [activeTrack]);

  // ----------------------------------------------------------------------
  // Microphone Controls
  // ----------------------------------------------------------------------
  const startRecording = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        showToast('Microphone recording is not supported in this browser.', 'error');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        setRecordedBlob(blob);
        const url = URL.createObjectURL(blob);
        setRecordedAudioUrl(url);

        // Stop all tracks on the stream to release microphone
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start(250); // Emit data every 250ms
      setIsRecording(true);
      setIsPaused(false);
      setRecordingSeconds(0);
      setRecordedBlob(null);
      setRecordedAudioUrl(null);

      // Start elapsed timer
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);

      showToast('Microphone active. Recording your voice note...', 'info');
    } catch (err: any) {
      console.error('Microphone error:', err);
      showToast(`Microphone access error: ${err.message || 'Permission denied'}`, 'error');
    }
  };

  const pauseRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.pause();
      setIsPaused(true);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    }
  };

  const resumeRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'paused') {
      mediaRecorderRef.current.resume();
      setIsPaused(false);
      timerIntervalRef.current = setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);
    }
  };

  const stopRecordingAndTranscribe = () => {
    if (!mediaRecorderRef.current) return;

    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    setIsRecording(false);
    setIsPaused(false);

    mediaRecorderRef.current.onstop = async () => {
      const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
      setRecordedBlob(blob);
      const url = URL.createObjectURL(blob);
      setRecordedAudioUrl(url);

      // Release microphone
      if (mediaRecorderRef.current?.stream) {
        mediaRecorderRef.current.stream.getTracks().forEach(t => t.stop());
      }

      // Now auto-transcribe with gemini-3.5-transcribe
      await performTranscription(blob, recordingSeconds);
    };

    mediaRecorderRef.current.stop();
  };

  const cancelRecording = () => {
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      if (mediaRecorderRef.current.stream) {
        mediaRecorderRef.current.stream.getTracks().forEach(t => t.stop());
      }
    }
    setIsRecording(false);
    setIsPaused(false);
    setRecordingSeconds(0);
    setRecordedBlob(null);
    setRecordedAudioUrl(null);
  };

  const performTranscription = async (blob: Blob, durationSec?: number) => {
    setIsTranscribing(true);
    try {
      const res = await api.transcribeAudio(blob);
      if (res && res.transcription) {
        const text = res.transcription.trim();
        setTranscriptionText(text);

        // Find candidate and job names if selected
        const candidate = candidates.find(c => c.id === selectedCandidateId);
        const job = jobs.find(j => j.id === selectedJobId);

        const newRecord: SavedTranscription = {
          id: `tr_${Date.now()}`,
          text,
          purpose: transcriptionPurpose,
          candidateName: candidate?.name,
          jobTitle: job?.title,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          durationSeconds: durationSec
        };

        setTranscriptionHistory(prev => [newRecord, ...prev]);
        showToast('Transcribed successfully using gemini-3.5-transcribe!', 'success');
      } else {
        showToast('Transcription completed, but no text was detected.', 'warning');
      }
    } catch (err: any) {
      console.error('Transcription error:', err);
      showToast(`Transcription failed: ${err.message}`, 'error');
    } finally {
      setIsTranscribing(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/') && !file.name.match(/\.(mp3|wav|ogg|m4a|webm)$/i)) {
      showToast('Please select a valid audio file (.wav, .mp3, .m4a, .webm).', 'error');
      return;
    }

    setRecordedBlob(file);
    const url = URL.createObjectURL(file);
    setRecordedAudioUrl(url);
    performTranscription(file);
  };

  const handleCopyTranscription = () => {
    if (!transcriptionText) return;
    navigator.clipboard.writeText(transcriptionText);
    setCopiedTranscription(true);
    showToast('Transcription copied to clipboard!', 'success');
    setTimeout(() => setCopiedTranscription(false), 2000);
  };

  const handleSaveAsCandidateNote = async () => {
    if (!selectedCandidateId) {
      showToast('Please select a candidate from the dropdown first.', 'warning');
      return;
    }
    if (!transcriptionText.trim()) {
      showToast('No transcription text to save.', 'warning');
      return;
    }

    setSavingAsNote(true);
    try {
      const noteContent = `[Voice Memo - ${transcriptionPurpose}] ${transcriptionText.trim()}`;
      await api.addNote(selectedCandidateId, noteContent, selectedJobId || undefined);
      showToast('Saved directly as candidate note!', 'success');
    } catch (err: any) {
      showToast(`Failed to save note: ${err.message}`, 'error');
    } finally {
      setSavingAsNote(false);
    }
  };

  // ----------------------------------------------------------------------
  // Lyria Music Generation Handler
  // ----------------------------------------------------------------------
  const handleGenerateMusic = async () => {
    if (!musicPrompt.trim()) {
      showToast('Please enter a description or prompt for the music track.', 'warning');
      return;
    }

    setIsGeneratingMusic(true);
    try {
      const model = trackType === 'pro' ? 'lyria-3-pro-preview' : 'lyria-3-clip-preview';
      showToast(`Generating music with ${model}... This may take a few moments.`, 'info');

      const res = await api.generateMusic(musicPrompt.trim(), trackType);

      if (res && res.audioBase64) {
        // Decode base64 audio into Blob URL
        const binary = atob(res.audioBase64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        const mimeType = res.mimeType || 'audio/wav';
        const blob = new Blob([bytes], { type: mimeType });
        const audioUrl = URL.createObjectURL(blob);

        const newTrack: GeneratedTrack = {
          id: `trk_${Date.now()}`,
          title: musicPrompt.length > 50 ? `${musicPrompt.slice(0, 47)}...` : musicPrompt,
          prompt: res.prompt || musicPrompt,
          trackType: (res.trackType as 'clip' | 'pro') || trackType,
          modelUsed: res.modelUsed || model,
          audioUrl,
          mimeType,
          lyrics: res.lyrics,
          generatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };

        setGeneratedTracks(prev => [newTrack, ...prev]);
        setActiveTrack(newTrack);
        setIsPlaying(true);
        showToast('Music track generated successfully with Lyria!', 'success');
      } else {
        showToast('Music generation completed, but no audio stream was received.', 'error');
      }
    } catch (err: any) {
      console.error('Music generation error:', err);
      showToast(`Lyria generation failed: ${err.message}`, 'error');
    } finally {
      setIsGeneratingMusic(false);
    }
  };

  const togglePlayPause = () => {
    const audio = audioPlayerRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().then(() => setIsPlaying(true)).catch(e => console.error(e));
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const audio = audioPlayerRef.current;
    if (!audio) return;
    const newTime = parseFloat(e.target.value);
    audio.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVol = parseFloat(e.target.value);
    setVolume(newVol);
    if (audioPlayerRef.current) {
      audioPlayerRef.current.volume = newVol;
    }
    setIsMuted(newVol === 0);
  };

  const toggleMute = () => {
    if (!audioPlayerRef.current) return;
    if (isMuted) {
      audioPlayerRef.current.volume = volume || 0.8;
      setIsMuted(false);
    } else {
      audioPlayerRef.current.volume = 0;
      setIsMuted(true);
    }
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remaining = Math.floor(secs % 60);
    return `${mins.toString().padStart(2, '0')}:${remaining.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Studio Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden border border-slate-800">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold border border-indigo-500/30">
              <Headphones className="w-3.5 h-3.5" />
              <span>AI Audio Studio & Voice Intelligence</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Recruiter Voice & Sound Intelligence
            </h1>
            <p className="text-slate-300 text-sm leading-relaxed">
              Dictate interview debriefs and screening notes with high-accuracy speech transcription (<span className="text-indigo-300 font-mono text-xs">gemini-3.5-transcribe</span>), or generate focused ambient soundtracks for deep resume reviews (<span className="text-indigo-300 font-mono text-xs">lyria-3-clip-preview</span> / <span className="text-indigo-300 font-mono text-xs">lyria-3-pro-preview</span>).
            </p>
          </div>

          {/* Model indicator badges */}
          <div className="flex flex-col sm:flex-row md:flex-col gap-2 shrink-0">
            <div className="px-3.5 py-2 rounded-xl bg-slate-800/80 border border-slate-700/80 text-xs flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <div className="leading-tight">
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Speech Engine</div>
                <div className="font-mono text-white text-xs font-medium">gemini-3.5-transcribe</div>
              </div>
            </div>
            <div className="px-3.5 py-2 rounded-xl bg-slate-800/80 border border-slate-700/80 text-xs flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-400" />
              <div className="leading-tight">
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Music Engine</div>
                <div className="font-mono text-white text-xs font-medium">lyria-3-clip & pro-preview</div>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 mt-8 pt-4 border-t border-slate-800/80">
          <button
            onClick={() => setActiveTab('transcribe')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeTab === 'transcribe'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Mic className="w-4 h-4" />
            <span>Voice Dictation & Transcription</span>
          </button>
          <button
            onClick={() => setActiveTab('music')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeTab === 'music'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Music className="w-4 h-4" />
            <span>Focus Music & Recruitment Soundtracks</span>
          </button>
        </div>
      </div>

      {/* ================================================================================== */}
      {/* TAB 1: VOICE DICTATION & TRANSCRIPTION (gemini-3.5-transcribe) */}
      {/* ================================================================================== */}
      {activeTab === 'transcribe' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Live Recording & Audio Input */}
          <div className="lg:col-span-6 space-y-6">
            {/* Context Linking Card */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-4">
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-600" />
                <span>Screening Context & Attribution</span>
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Associate Candidate (Optional)
                  </label>
                  <select
                    value={selectedCandidateId}
                    onChange={e => setSelectedCandidateId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:border-indigo-500 text-slate-900"
                  >
                    <option value="">-- No candidate linked --</option>
                    {candidates.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.email})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Associate Job Opening (Optional)
                  </label>
                  <select
                    value={selectedJobId}
                    onChange={e => setSelectedJobId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:border-indigo-500 text-slate-900"
                  >
                    <option value="">-- No job linked --</option>
                    {jobs.map(j => (
                      <option key={j.id} value={j.id}>
                        {j.title} ({j.company})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1 text-xs">
                  Voice Note Category
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    'Interview Debrief',
                    'Technical Evaluation',
                    'Cultural Fit Memo',
                    'Job Description Dictation'
                  ].map(cat => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setTranscriptionPurpose(cat)}
                      className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold border transition-all text-center ${
                        transcriptionPurpose === cat
                          ? 'bg-indigo-50 border-indigo-300 text-indigo-700'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Microphone Recording Console */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col items-center text-center space-y-6">
              <div className="space-y-1">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                  Real-Time Microphone Input
                </span>
                <h3 className="text-lg font-extrabold text-slate-900">
                  Record Voice Note
                </h3>
                <p className="text-xs text-slate-500 max-w-sm">
                  Speak clearly into your microphone. When stopped, Gemini 3.5 Transcribe will convert your speech to text.
                </p>
              </div>

              {/* Pulsing Visualizer & Timer */}
              <div className="relative flex flex-col items-center justify-center my-4">
                {isRecording && (
                  <div className="absolute w-36 h-36 rounded-full bg-rose-500/20 animate-ping pointer-events-none" />
                )}
                {isRecording && !isPaused && (
                  <div className="absolute w-44 h-44 rounded-full bg-indigo-500/10 animate-pulse pointer-events-none" />
                )}

                <button
                  type="button"
                  onClick={isRecording ? (isPaused ? resumeRecording : pauseRecording) : startRecording}
                  disabled={isTranscribing}
                  className={`relative z-10 w-24 h-24 rounded-full flex flex-col items-center justify-center text-white transition-all shadow-xl ${
                    isRecording
                      ? isPaused
                        ? 'bg-amber-500 hover:bg-amber-600 shadow-amber-500/30'
                        : 'bg-rose-500 hover:bg-rose-600 shadow-rose-500/30'
                      : 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-600/30 hover:scale-105'
                  }`}
                >
                  {isRecording ? (
                    isPaused ? (
                      <>
                        <Play className="w-8 h-8 fill-current" />
                        <span className="text-[10px] font-bold mt-1">RESUME</span>
                      </>
                    ) : (
                      <>
                        <Pause className="w-8 h-8 fill-current" />
                        <span className="text-[10px] font-bold mt-1">PAUSE</span>
                      </>
                    )
                  ) : (
                    <>
                      <Mic className="w-8 h-8" />
                      <span className="text-[10px] font-bold mt-1">RECORD</span>
                    </>
                  )}
                </button>
              </div>

              {/* Timer Display */}
              <div className="space-y-1">
                <div className="text-3xl font-mono font-bold text-slate-900 tracking-wider">
                  {formatTime(recordingSeconds)}
                </div>
                <div className="text-xs font-medium text-slate-500 flex items-center justify-center gap-1.5">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      isRecording
                        ? isPaused
                          ? 'bg-amber-400'
                          : 'bg-rose-500 animate-pulse'
                        : 'bg-slate-300'
                    }`}
                  />
                  <span>
                    {isRecording
                      ? isPaused
                        ? 'Recording Paused'
                        : 'Recording in Progress...'
                      : 'Ready to Record'}
                  </span>
                </div>
              </div>

              {/* Action Buttons while recording */}
              {isRecording && (
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={stopRecordingAndTranscribe}
                    className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs shadow-md transition-all flex items-center gap-2"
                  >
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Stop & Transcribe with Gemini</span>
                  </button>
                  <button
                    type="button"
                    onClick={cancelRecording}
                    className="px-3.5 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-100 font-semibold text-xs transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              )}

              {/* Audio playback preview if recorded */}
              {recordedAudioUrl && !isRecording && (
                <div className="w-full pt-4 border-t border-slate-100 flex flex-col items-center gap-3">
                  <span className="text-xs font-semibold text-slate-600">
                    Recorded Audio Preview:
                  </span>
                  <audio controls src={recordedAudioUrl} className="w-full max-w-sm h-10" />
                  <button
                    type="button"
                    onClick={() => performTranscription(recordedBlob!, recordingSeconds)}
                    disabled={isTranscribing}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-xs flex items-center gap-2"
                  >
                    {isTranscribing ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <RefreshCw className="w-3.5 h-3.5" />
                    )}
                    <span>Re-Transcribe Recording</span>
                  </button>
                </div>
              )}

              {/* Upload alternate audio */}
              <div className="w-full pt-4 border-t border-slate-100">
                <label className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-dashed border-slate-300 hover:border-indigo-500 hover:bg-indigo-50/50 cursor-pointer text-xs font-medium text-slate-600 transition-colors">
                  <FileAudio className="w-4 h-4 text-indigo-600" />
                  <span>Or upload pre-recorded audio (.wav, .mp3, .webm)</span>
                  <input
                    type="file"
                    accept="audio/*,.wav,.mp3,.m4a,.webm"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Right Column: Transcription Output & Actions */}
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col h-full min-h-[480px]">
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      Gemini 3.5 Transcription Result
                    </h3>
                    <div className="text-[11px] text-slate-500">
                      Model: <span className="font-mono text-indigo-600">gemini-3.5-transcribe</span>
                    </div>
                  </div>
                </div>

                {transcriptionText && (
                  <button
                    onClick={handleCopyTranscription}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 transition-colors"
                  >
                    {copiedTranscription ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-600">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Text</span>
                      </>
                    )}
                  </button>
                )}
              </div>

              {/* Body */}
              <div className="flex-1 py-4">
                {isTranscribing ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-3">
                    <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
                    <div className="text-sm font-semibold text-slate-900">
                      Transcribing audio with gemini-3.5-transcribe...
                    </div>
                    <p className="text-xs text-slate-500 max-w-xs">
                      Formatting speech into verbatim text with recruitment terminology preservation.
                    </p>
                  </div>
                ) : transcriptionText ? (
                  <div className="space-y-4">
                    <textarea
                      value={transcriptionText}
                      onChange={e => setTranscriptionText(e.target.value)}
                      rows={12}
                      className="w-full p-4 rounded-xl border border-slate-200 bg-slate-50/50 text-slate-900 text-sm leading-relaxed focus:bg-white focus:outline-hidden focus:border-indigo-500 transition-all font-sans resize-y"
                    />

                    {/* Word & char count */}
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>
                        Words: {transcriptionText.split(/\s+/).filter(Boolean).length} | Characters:{' '}
                        {transcriptionText.length}
                      </span>
                      <span>Category: {transcriptionPurpose}</span>
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400 space-y-2">
                    <Mic className="w-10 h-10 text-slate-300" />
                    <div className="text-sm font-medium text-slate-600">
                      No transcription generated yet
                    </div>
                    <p className="text-xs text-slate-400 max-w-xs">
                      Click the Record button on the left to dictate an interview note or screening observation.
                    </p>
                  </div>
                )}
              </div>

              {/* Bottom Actions */}
              {transcriptionText && !isTranscribing && (
                <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center gap-2 justify-between">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleSaveAsCandidateNote}
                      disabled={savingAsNote || !selectedCandidateId}
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-semibold text-xs shadow-xs transition-colors flex items-center gap-2"
                      title={
                        selectedCandidateId
                          ? 'Save this transcription to candidate profile'
                          : 'Select a candidate above to enable'
                      }
                    >
                      {savingAsNote ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Plus className="w-3.5 h-3.5" />
                      )}
                      <span>Save as Candidate Note</span>
                    </button>
                    {!selectedCandidateId && (
                      <span className="text-[11px] text-amber-600 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> Select candidate first
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setTranscriptionText('');
                      setRecordedBlob(null);
                      setRecordedAudioUrl(null);
                    }}
                    className="px-3 py-2 rounded-xl text-slate-500 hover:text-slate-700 hover:bg-slate-100 text-xs font-semibold transition-colors"
                  >
                    Clear Text
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Bottom Row: Recent Transcription Logs */}
          {transcriptionHistory.length > 0 && (
            <div className="lg:col-span-12 bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-600" />
                <span>Session Transcription History</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {transcriptionHistory.map(item => (
                  <div
                    key={item.id}
                    className="p-4 rounded-xl border border-slate-200/80 bg-slate-50/60 hover:bg-white hover:border-indigo-300 transition-all space-y-2.5 flex flex-col justify-between"
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-[11px] text-slate-500">
                        <span className="px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 font-semibold border border-indigo-200/50">
                          {item.purpose}
                        </span>
                        <span>{item.timestamp}</span>
                      </div>
                      {item.candidateName && (
                        <div className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-slate-500" />
                          <span>Candidate: {item.candidateName}</span>
                        </div>
                      )}
                      <p className="text-xs text-slate-700 line-clamp-3 leading-relaxed">
                        "{item.text}"
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between">
                      <button
                        onClick={() => {
                          setTranscriptionText(item.text);
                          setTranscriptionPurpose(item.purpose);
                        }}
                        className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold"
                      >
                        Load into Editor
                      </button>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(item.text);
                          showToast('Copied transcription!', 'success');
                        }}
                        className="p-1 rounded-md text-slate-400 hover:text-slate-600 hover:bg-slate-200"
                        title="Copy text"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================================================================================== */}
      {/* TAB 2: LYRIA MUSIC GENERATION (lyria-3-clip-preview & lyria-3-pro-preview) */}
      {/* ================================================================================== */}
      {activeTab === 'music' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Generator Controls & Presets */}
            <div className="lg:col-span-7 space-y-6">
              <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs space-y-5">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-indigo-600" />
                    <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                      Lyria Music Engine
                    </span>
                  </div>
                  <h2 className="text-lg font-extrabold text-slate-900">
                    Generate Recruitment Focus Audio & Soundtracks
                  </h2>
                  <p className="text-xs text-slate-500">
                    Prompt AI models to create original soundtrack clips or full-length tracks for concentration, interviews, or hiring campaigns.
                  </p>
                </div>

                {/* Model / Track Type Selector */}
                <div className="space-y-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-600">
                    Track Duration & Model Selection
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setTrackType('clip')}
                      className={`p-3.5 rounded-xl border text-left transition-all ${
                        trackType === 'clip'
                          ? 'border-indigo-600 bg-indigo-50/60 ring-2 ring-indigo-600/20'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-slate-900">
                          Short Clip (Up to 30s)
                        </span>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-sm bg-indigo-100 text-indigo-700 font-semibold">
                          30s
                        </span>
                      </div>
                      <div className="text-[11px] font-mono text-indigo-700 font-medium">
                        lyria-3-clip-preview
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">
                        Best for notification chimes, short audio transitions, or fast focus loops.
                      </p>
                    </button>

                    <button
                      type="button"
                      onClick={() => setTrackType('pro')}
                      className={`p-3.5 rounded-xl border text-left transition-all ${
                        trackType === 'pro'
                          ? 'border-indigo-600 bg-indigo-50/60 ring-2 ring-indigo-600/20'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-slate-900">
                          Full-Length Track
                        </span>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-sm bg-purple-100 text-purple-700 font-semibold">
                          Full Track
                        </span>
                      </div>
                      <div className="text-[11px] font-mono text-purple-700 font-medium">
                        lyria-3-pro-preview
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">
                        Extended cinematic and rich arrangement for deep focus resume reviews.
                      </p>
                    </button>
                  </div>
                </div>

                {/* Prompt Presets */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
                      Recruitment Sound Presets
                    </label>
                    <span className="text-[11px] text-slate-400">Click to apply</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {promptPresets.map((preset, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          setMusicPrompt(preset.prompt);
                          setTrackType(preset.type);
                        }}
                        className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-indigo-50/60 hover:border-indigo-300 text-left transition-all group"
                      >
                        <div className="flex items-center justify-between text-xs font-bold text-slate-800 group-hover:text-indigo-700">
                          <span>{preset.title}</span>
                          <span className="text-[10px] font-mono px-1 py-0.2 rounded-sm bg-slate-200 group-hover:bg-indigo-200 text-slate-700">
                            {preset.type === 'pro' ? 'Pro' : 'Clip'}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                          {preset.desc}
                        </p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Prompt Textarea */}
                <div className="space-y-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-600">
                    Music Prompt / Sound Description
                  </label>
                  <textarea
                    value={musicPrompt}
                    onChange={e => setMusicPrompt(e.target.value)}
                    rows={3}
                    placeholder="Describe instruments, tempo, genre, mood, and style (e.g. Chill Lo-fi, Synthwave, Acoustic Piano)..."
                    className="w-full p-3.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:border-indigo-500 text-xs sm:text-sm text-slate-900 leading-relaxed font-sans"
                  />
                </div>

                {/* Generate Button */}
                <button
                  type="button"
                  onClick={handleGenerateMusic}
                  disabled={isGeneratingMusic || !musicPrompt.trim()}
                  className="w-full py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-sm shadow-md shadow-indigo-600/30 transition-all flex items-center justify-center gap-2"
                >
                  {isGeneratingMusic ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>
                        Generating with {trackType === 'pro' ? 'lyria-3-pro-preview' : 'lyria-3-clip-preview'}...
                      </span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>
                        Generate Music ({trackType === 'pro' ? 'Full Track' : '30s Clip'})
                      </span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Right: Active Audio Player & Waveform Display */}
            <div className="lg:col-span-5 space-y-6">
              <div className="bg-slate-900 rounded-2xl p-6 text-white border border-slate-800 shadow-xl flex flex-col justify-between min-h-[460px]">
                {/* Player Header */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/40 text-indigo-400 flex items-center justify-center">
                      <Music className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white">Audio Playback Console</h3>
                      <div className="text-[11px] text-slate-400">
                        {activeTrack ? activeTrack.modelUsed : 'Awaiting track generation'}
                      </div>
                    </div>
                  </div>

                  {activeTrack && (
                    <a
                      href={activeTrack.audioUrl}
                      download={`talentai_soundtrack_${activeTrack.id}.wav`}
                      className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                      title="Download WAV file"
                    >
                      <Download className="w-4 h-4" />
                    </a>
                  )}
                </div>

                {/* Animated Waveform Visualizer */}
                <div className="my-8 flex flex-col items-center justify-center text-center space-y-4">
                  {isGeneratingMusic ? (
                    <div className="space-y-4 py-8">
                      <Loader2 className="w-12 h-12 text-indigo-400 animate-spin mx-auto" />
                      <div className="space-y-1">
                        <div className="text-sm font-bold text-white">
                          Synthesizing Audio Stream...
                        </div>
                        <div className="text-xs text-slate-400 font-mono">
                          Generating with Lyria AI
                        </div>
                      </div>
                    </div>
                  ) : activeTrack ? (
                    <div className="w-full space-y-4">
                      {/* Simulated Graphic Equalizer Bars */}
                      <div className="h-28 flex items-end justify-center gap-1.5 px-4">
                        {[40, 65, 80, 50, 95, 70, 45, 85, 90, 60, 75, 55, 88, 72, 60, 48, 82, 64].map(
                          (val, i) => (
                            <div
                              key={i}
                              style={{
                                height: isPlaying ? `${Math.max(15, (val * ((i % 3) + 1)) % 100)}%` : '15%',
                                transition: 'height 0.15s ease'
                              }}
                              className={`w-2.5 rounded-full transition-all ${
                                isPlaying
                                  ? 'bg-gradient-to-t from-indigo-600 via-indigo-400 to-blue-300'
                                  : 'bg-slate-700'
                              }`}
                            />
                          )
                        )}
                      </div>

                      <div className="text-center px-4 space-y-1">
                        <div className="text-sm font-bold text-white line-clamp-2">
                          "{activeTrack.title}"
                        </div>
                        <div className="text-[11px] text-slate-400">
                          Format: <span className="font-mono text-indigo-300">{activeTrack.mimeType}</span> |{' '}
                          Model: <span className="font-mono text-indigo-300">{activeTrack.modelUsed}</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="py-12 space-y-2 text-slate-500">
                      <Headphones className="w-12 h-12 mx-auto stroke-1" />
                      <div className="text-xs font-semibold text-slate-400">No Track Playing</div>
                      <p className="text-[11px] text-slate-500 max-w-xs">
                        Select a preset on the left or type your own prompt, then click Generate.
                      </p>
                    </div>
                  )}

                  {/* Hidden HTML Audio element for playback */}
                  {activeTrack && (
                    <audio
                      ref={audioPlayerRef}
                      src={activeTrack.audioUrl}
                      preload="auto"
                    />
                  )}
                </div>

                {/* Player Controls */}
                {activeTrack ? (
                  <div className="space-y-4 pt-4 border-t border-slate-800">
                    {/* Scrubber Bar */}
                    <div className="space-y-1">
                      <input
                        type="range"
                        min={0}
                        max={duration || 100}
                        step={0.1}
                        value={currentTime}
                        onChange={handleSeek}
                        className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                      />
                      <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                        <span>{formatTime(currentTime)}</span>
                        <span>{formatTime(duration)}</span>
                      </div>
                    </div>

                    {/* Buttons: Play, Mute, Volume */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={toggleMute}
                          className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                          title={isMuted ? 'Unmute' : 'Mute'}
                        >
                          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                        </button>
                        <input
                          type="range"
                          min={0}
                          max={1}
                          step={0.05}
                          value={isMuted ? 0 : volume}
                          onChange={handleVolumeChange}
                          className="w-20 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                        />
                      </div>

                      {/* Main Play/Pause Button */}
                      <button
                        type="button"
                        onClick={togglePlayPause}
                        className="w-12 h-12 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center shadow-lg shadow-indigo-600/40 transition-transform hover:scale-105 active:scale-95"
                      >
                        {isPlaying ? (
                          <Pause className="w-5 h-5 fill-current" />
                        ) : (
                          <Play className="w-5 h-5 fill-current ml-0.5" />
                        )}
                      </button>

                      <div className="w-24 text-right">
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-indigo-300 font-semibold border border-slate-700">
                          {activeTrack.trackType === 'pro' ? 'Full Track' : '30s Clip'}
                        </span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-2 text-xs text-slate-600">
                    Controls will activate once a track is generated.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Library of Generated Tracks in this Session */}
          {generatedTracks.length > 0 && (
            <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Music className="w-4 h-4 text-indigo-600" />
                <span>Generated Soundtracks in Session ({generatedTracks.length})</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {generatedTracks.map(trk => (
                  <div
                    key={trk.id}
                    className={`p-4 rounded-xl border transition-all space-y-3 ${
                      activeTrack?.id === trk.id
                        ? 'border-indigo-600 bg-indigo-50/40 shadow-xs'
                        : 'border-slate-200 bg-slate-50/50 hover:bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px] text-slate-500">
                      <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-700 font-mono font-bold">
                        {trk.modelUsed}
                      </span>
                      <span>{trk.generatedAt}</span>
                    </div>

                    <div className="text-xs font-semibold text-slate-800 line-clamp-2">
                      "{trk.prompt}"
                    </div>

                    <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => {
                          setActiveTrack(trk);
                          setIsPlaying(true);
                        }}
                        className="flex items-center gap-1.5 text-xs text-indigo-600 hover:text-indigo-800 font-bold"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Play Track</span>
                      </button>

                      <a
                        href={trk.audioUrl}
                        download={`soundtrack_${trk.id}.wav`}
                        className="flex items-center gap-1 text-[11px] text-slate-500 hover:text-slate-800"
                      >
                        <Download className="w-3 h-3" />
                        <span>WAV</span>
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
export default AudioStudioPage;

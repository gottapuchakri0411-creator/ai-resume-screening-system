import React, { useState, useEffect } from 'react';
import {
  Settings,
  User,
  ShieldCheck,
  Sparkles,
  Server,
  FileCheck2,
  CheckCircle2,
  Sliders,
  Building,
  Mail,
  Briefcase,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { useToast } from '../components/Toast';

export const SettingsPage: React.FC = () => {
  const { user } = useAuth();
  const { showToast } = useToast();

  const [healthStatus, setHealthStatus] = useState<{ status: string; geminiConfigured: boolean } | null>(null);

  useEffect(() => {
    checkBackendHealth();
  }, []);

  const checkBackendHealth = async () => {
    try {
      const res = await api.checkHealth();
      setHealthStatus(res);
    } catch (err) {
      console.warn('Backend health check error:', err);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">System Settings &amp; Governance</h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Recruiter profile parameters, Responsible AI charter, and screening pipeline configuration
        </p>
      </div>

      {/* Recruiter Profile Details */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <User className="w-4 h-4 text-indigo-600" />
          <h3 className="text-sm font-bold text-slate-900">Recruiter Profile Information</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <span className="text-slate-400 block font-medium">Recruiter Name</span>
            <span className="font-bold text-slate-800 text-sm">{user?.name || 'Recruiter'}</span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <span className="text-slate-400 block font-medium">Work Email Address</span>
            <span className="font-bold text-slate-800 text-sm">{user?.email}</span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <span className="text-slate-400 block font-medium">Organization</span>
            <span className="font-bold text-slate-800 text-sm">{user?.company || 'Organization'}</span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <span className="text-slate-400 block font-medium">Designation / Role</span>
            <span className="font-bold text-slate-800 text-sm">{user?.role || 'Recruiter'}</span>
          </div>
        </div>
      </div>

      {/* Responsible AI Compliance Charter */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3 text-indigo-600">
          <ShieldCheck className="w-5 h-5" />
          <h3 className="text-sm font-bold text-slate-900">Responsible AI Screening Charter</h3>
        </div>

        <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
          <p>
            The <strong>AI Resume Screening System</strong> is built with strict ethical alignment to ensure non-discriminatory candidate screening.
            Automated recommendations are strictly decision-support tools and the recruiter always retains ultimate hiring authority.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-100 space-y-2">
              <span className="font-bold text-emerald-800 block text-xs flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Permitted Evaluation Dimensions
              </span>
              <ul className="space-y-1 text-slate-700 text-[11px] list-disc list-inside">
                <li>Demonstrated Technical &amp; Role Skills</li>
                <li>Verifiable Years of Professional Experience</li>
                <li>Relevant Degrees, Certifications, and Academia</li>
                <li>Demonstrated Projects and Technical Accomplishments</li>
                <li>Job Description keyword &amp; responsibility alignment</li>
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-rose-50/50 border border-rose-100 space-y-2">
              <span className="font-bold text-rose-800 block text-xs flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-rose-600" />
                Strictly Prohibited &amp; Excluded Dimensions
              </span>
              <ul className="space-y-1 text-slate-700 text-[11px] list-disc list-inside">
                <li>Gender, Biological Sex, Pronouns</li>
                <li>Race, Ethnicity, Caste, or Nationality</li>
                <li>Age, Date of Birth, Graduation Years (beyond tenure)</li>
                <li>Religion, Faith, or Political Affiliation</li>
                <li>Marital status, Disability, or Physical appearance</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Screening Algorithm Weights */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Sliders className="w-4 h-4 text-indigo-600" />
          <h3 className="text-sm font-bold text-slate-900">Multi-Layer Matching Model Weights</h3>
        </div>

        <div className="space-y-4 text-xs">
          <div>
            <div className="flex justify-between font-semibold mb-1">
              <span>Required &amp; Preferred Skills Verification (40%)</span>
              <span className="text-indigo-600">40%</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-2">
              <div className="bg-indigo-600 h-2 rounded-full" style={{ width: '40%' }} />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Normalized canonical dictionary matching against mandatory technical competencies.
            </p>
          </div>

          <div>
            <div className="flex justify-between font-semibold mb-1">
              <span>Gemini 3.8 Flash Semantic Reasoning (35%)</span>
              <span className="text-indigo-600">35%</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-2">
              <div className="bg-blue-600 h-2 rounded-full" style={{ width: '35%' }} />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Deep contextual evaluation of experience depth, responsibility fit, and education equivalence.
            </p>
          </div>

          <div>
            <div className="flex justify-between font-semibold mb-1">
              <span>TF-IDF Vector Cosine Similarity &amp; Keywords (25%)</span>
              <span className="text-indigo-600">25%</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-2">
              <div className="bg-purple-600 h-2 rounded-full" style={{ width: '25%' }} />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Deterministic mathematical token frequency overlap between Job Description and Resume text.
            </p>
          </div>
        </div>
      </div>

      {/* Backend & Model Service Status */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Server className="w-4 h-4 text-indigo-600" />
          <h3 className="text-sm font-bold text-slate-900">Service Infrastructure &amp; Parsers</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <span className="font-semibold text-slate-700">PDF &amp; DOCX Parsers</span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
              Active
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <span className="font-semibold text-slate-700">Gemini 3.8 Flash AI</span>
            <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
              healthStatus?.geminiConfigured
                ? 'bg-emerald-100 text-emerald-800'
                : 'bg-indigo-100 text-indigo-800'
            }`}>
              {healthStatus?.geminiConfigured ? 'Connected' : 'SDK Ready'}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <span className="font-semibold text-slate-700">Persistent Storage</span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
              Disk DB Synced
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  Briefcase,
  UploadCloud,
  Sparkles,
  ArrowLeft,
  FileText,
  Calendar,
  Building,
  MapPin,
  CheckCircle2,
  AlertCircle,
  Clock,
  Trash2,
  Eye,
  X,
  Loader2,
  Users,
  Award
} from 'lucide-react';
import { api } from '../services/api';
import { Job, Resume, ScreeningResult } from '../types';
import { StatusBadge, ScoreBadge } from '../components/ScoreBadge';
import { ResumeUploadModal } from '../components/ResumeUploadModal';
import { useToast } from '../components/Toast';

export const JobDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [job, setJob] = useState<Job | null>(null);
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [screeningResults, setScreeningResults] = useState<ScreeningResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [screeningLoading, setScreeningLoading] = useState(false);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [previewResume, setPreviewResume] = useState<Resume | null>(null);

  useEffect(() => {
    if (id) {
      loadJobDetails(id);
    }
  }, [id]);

  const loadJobDetails = async (jobId: string) => {
    setLoading(true);
    try {
      const res = await api.getJobById(jobId);
      setJob(res.job);
      setResumes(res.resumes);
      setScreeningResults(res.screeningResults);
    } catch (err: any) {
      showToast(err.message || 'Failed to load job details', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleTriggerScreening = async () => {
    if (!job) return;
    if (resumes.length === 0) {
      showToast('Please upload at least one resume before triggering screening.', 'info');
      setUploadModalOpen(true);
      return;
    }

    setScreeningLoading(true);
    try {
      const res = await api.triggerScreening(job.id);
      showToast(res.message || 'Screening pipeline completed successfully!', 'success');
      // Reload updated records
      await loadJobDetails(job.id);
      // Navigate to dedicated screening results page
      navigate(`/screening/${job.id}`);
    } catch (err: any) {
      showToast(err.message || 'Screening process encountered an issue', 'error');
    } finally {
      setScreeningLoading(false);
    }
  };

  const handleDeleteResume = async (resumeId: string, name: string) => {
    if (!window.confirm(`Delete resume "${name}"?`)) return;
    try {
      await api.deleteResume(resumeId);
      setResumes(prev => prev.filter(r => r.id !== resumeId));
      setScreeningResults(prev => prev.filter(s => s.resumeId !== resumeId));
      showToast(`Removed resume "${name}".`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to delete resume', 'error');
    }
  };

  if (loading) {
    return (
      <div className="py-24 flex flex-col items-center justify-center gap-2">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
        <span className="text-xs text-slate-500 font-medium">Loading position profile...</span>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="text-center py-20 bg-white rounded-2xl border border-slate-200 p-8">
        <AlertCircle className="w-10 h-10 text-rose-500 mx-auto mb-3" />
        <h3 className="text-base font-bold text-slate-800">Job Not Found</h3>
        <p className="text-xs text-slate-500 mt-1 mb-4">The requested position posting does not exist or was deleted.</p>
        <button
          onClick={() => navigate('/jobs')}
          className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
        >
          Return to Jobs
        </button>
      </div>
    );
  }

  const processedCount = resumes.filter(r => r.processingStatus === 'Processed').length;
  const pendingCount = resumes.filter(r => r.processingStatus === 'Uploaded' || r.processingStatus === 'Processing').length;

  return (
    <div className="space-y-6">
      {/* Top Breadcrumb & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/jobs')}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-200/60 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">{job.title}</h2>
              <StatusBadge status={job.status} />
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {job.company} • {job.department} • {job.location}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setUploadModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-800 text-xs font-semibold shadow-xs transition-colors"
          >
            <UploadCloud className="w-4 h-4 text-indigo-600" />
            <span>Upload Resumes</span>
          </button>

          <button
            onClick={handleTriggerScreening}
            disabled={screeningLoading || resumes.length === 0}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold shadow-xs shadow-indigo-600/30 transition-colors"
          >
            {screeningLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Screening Resumes...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Run NLP Screening ({resumes.length})</span>
              </>
            )}
          </button>

          {screeningResults.length > 0 && (
            <Link
              to={`/screening/${job.id}`}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs transition-colors"
            >
              <Award className="w-4 h-4" />
              <span>Rankings ({screeningResults.length})</span>
            </Link>
          )}
        </div>
      </div>

      {/* Main Grid: Left = Job Specs & Description; Right = Resume Intake List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Job Description & Criteria */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-5">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">
              Position Baseline &amp; Requirements
            </h3>

            {/* Quick Specs */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-slate-400 block mb-0.5">Employment Type</span>
                <span className="font-bold text-slate-800">{job.employmentType}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-slate-400 block mb-0.5">Min. Experience</span>
                <span className="font-bold text-slate-800">{job.minimumExperience} Years</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 col-span-2 sm:col-span-1">
                <span className="text-slate-400 block mb-0.5">Location</span>
                <span className="font-bold text-slate-800 truncate block">{job.location}</span>
              </div>
            </div>

            {/* Required Skills */}
            <div>
              <span className="text-xs font-bold text-slate-700 block mb-2">Required Skills</span>
              <div className="flex flex-wrap gap-1.5">
                {job.requiredSkills.map(skill => (
                  <span
                    key={skill}
                    className="px-2.5 py-1 rounded-lg bg-indigo-50 border border-indigo-100 text-indigo-700 text-xs font-semibold"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Preferred Skills */}
            {job.preferredSkills.length > 0 && (
              <div>
                <span className="text-xs font-bold text-slate-700 block mb-2">Preferred Skills</span>
                <div className="flex flex-wrap gap-1.5">
                  {job.preferredSkills.map(skill => (
                    <span
                      key={skill}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-600 text-xs font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Education Requirement */}
            <div>
              <span className="text-xs font-bold text-slate-700 block mb-1">Education Requirements</span>
              <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100">
                {job.educationRequirements}
              </p>
            </div>

            {/* Description */}
            <div>
              <span className="text-xs font-bold text-slate-700 block mb-2">Full Job Description</span>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-700 leading-relaxed font-mono whitespace-pre-line max-h-96 overflow-y-auto">
                {job.description}
              </div>
            </div>
          </div>
        </div>

        {/* Right: Resumes Intake Pool */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Uploaded Resumes</h3>
                <p className="text-xs text-slate-500">
                  {resumes.length} total • {processedCount} screened
                </p>
              </div>

              <button
                onClick={() => setUploadModalOpen(true)}
                className="p-1.5 rounded-lg text-indigo-600 hover:bg-indigo-50 transition-colors"
                title="Upload Resumes"
              >
                <UploadCloud className="w-5 h-5" />
              </button>
            </div>

            {resumes.length === 0 ? (
              <div className="py-10 text-center flex flex-col items-center">
                <FileText className="w-8 h-8 text-slate-300 mb-2" />
                <p className="text-xs font-semibold text-slate-700">No resumes uploaded yet</p>
                <p className="text-[11px] text-slate-400 max-w-[200px] mt-1 mb-4">
                  Upload PDF or DOCX candidate resumes to screen them against this job.
                </p>
                <button
                  onClick={() => setUploadModalOpen(true)}
                  className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold transition-colors"
                >
                  Upload First Resume
                </button>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
                {resumes.map(resume => {
                  const screening = screeningResults.find(s => s.resumeId === resume.id);

                  return (
                    <div
                      key={resume.id}
                      className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:border-indigo-200 transition-all space-y-2"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2 min-w-0">
                          <FileText className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-slate-900 truncate" title={resume.originalName}>
                              {resume.originalName}
                            </p>
                            <span className="text-[10px] text-slate-400 uppercase font-semibold">
                              {resume.fileType} • {(resume.fileSize / 1024).toFixed(0)} KB
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={() => setPreviewResume(resume)}
                            className="p-1 rounded text-slate-400 hover:text-indigo-600 hover:bg-indigo-50"
                            title="Preview Extracted Text"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteResume(resume.id, resume.originalName)}
                            className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Status / Score Bar */}
                      <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-[11px]">
                        {resume.processingStatus === 'Processed' && screening ? (
                          <>
                            <ScoreBadge score={screening.matchScore} size="sm" showLabel />
                            <StatusBadge status={screening.status} />
                          </>
                        ) : resume.processingStatus === 'Failed' ? (
                          <span className="text-rose-600 font-medium flex items-center gap-1">
                            <AlertCircle className="w-3 h-3" />
                            Extraction Failed
                          </span>
                        ) : (
                          <span className="text-slate-500 font-medium flex items-center gap-1">
                            <Clock className="w-3 h-3 text-amber-500" />
                            Ready for Screening
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Extracted Text Preview Modal */}
      {previewResume && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] shadow-2xl border border-slate-200 flex flex-col overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Extracted Resume Text</h3>
                <p className="text-xs text-slate-500">{previewResume.originalName}</p>
              </div>
              <button
                onClick={() => setPreviewResume(null)}
                className="p-1 rounded text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1 font-mono text-xs leading-relaxed text-slate-800 bg-slate-50 whitespace-pre-wrap">
              {previewResume.extractedText || 'Unable to extract readable text from this resume.'}
            </div>

            <div className="px-6 py-3 border-t border-slate-200 bg-white flex justify-end">
              <button
                onClick={() => setPreviewResume(null)}
                className="px-4 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-700"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload Modal */}
      <ResumeUploadModal
        jobId={job.id}
        jobTitle={job.title}
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        onSuccess={() => loadJobDetails(job.id)}
      />
    </div>
  );
};

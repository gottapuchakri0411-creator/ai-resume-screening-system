import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Users,
  Search,
  Filter,
  ExternalLink,
  Briefcase,
  Mail,
  Phone,
  Calendar,
  Sparkles,
  Loader2,
  FileText
} from 'lucide-react';
import { api } from '../services/api';
import { Candidate, Job } from '../types';
import { ScoreBadge, StatusBadge } from '../components/ScoreBadge';
import { useToast } from '../components/Toast';
import { EmptyState } from '../components/EmptyState';

export const CandidatesPage: React.FC = () => {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);

  const [searchQuery, setSearchQuery] = useState('');
  const [jobFilter, setJobFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const { showToast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [candRes, jobsRes] = await Promise.all([
        api.getCandidates(),
        api.getJobs()
      ]);
      setCandidates(candRes.candidates);
      setJobs(jobsRes.jobs);
    } catch (err: any) {
      showToast(err.message || 'Failed to load candidates', 'error');
    } finally {
      setLoading(false);
    }
  };

  const filteredCandidates = candidates.filter(c => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.email && c.email.toLowerCase().includes(searchQuery.toLowerCase())) ||
      c.extractedSkills.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesJob = jobFilter === 'ALL' || c.jobId === jobFilter;
    const matchesStatus =
      statusFilter === 'ALL' || (c.screening && c.screening.status === statusFilter);

    return matchesSearch && matchesJob && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Candidate Talent Pool</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Aggregated profiles extracted and screened across all organizational job openings
          </p>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search candidate name, email, or extracted competency..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400 text-xs focus:outline-hidden focus:border-indigo-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          {/* Job Filter */}
          <select
            value={jobFilter}
            onChange={e => setJobFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-800 focus:outline-hidden max-w-[200px] truncate"
          >
            <option value="ALL">All Jobs ({jobs.length})</option>
            {jobs.map(j => (
              <option key={j.id} value={j.id}>
                {j.title}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-800 focus:outline-hidden"
          >
            <option value="ALL">All Statuses</option>
            <option value="Shortlisted">Shortlisted</option>
            <option value="Under Review">Under Review</option>
            <option value="Reviewed">Reviewed</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Candidates Grid */}
      {loading ? (
        <div className="py-20 flex flex-col items-center justify-center gap-2">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
          <span className="text-xs text-slate-500 font-medium">Loading candidate talent pool...</span>
        </div>
      ) : filteredCandidates.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No Candidates Found"
          description={
            candidates.length === 0
              ? 'No candidate profiles have been processed yet. Upload resumes to a job to automatically extract and screen applicants.'
              : 'No candidate matches the current search and filter combination.'
          }
          actionText={candidates.length === 0 ? 'Go to Job Postings' : 'Reset Search'}
          onAction={candidates.length === 0 ? () => navigate('/jobs') : () => { setSearchQuery(''); setJobFilter('ALL'); setStatusFilter('ALL'); }}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCandidates.map(candidate => (
            <div
              key={candidate.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-indigo-300 transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                {/* Header: Name and Match Score */}
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <Link
                      to={`/candidates/${candidate.id}`}
                      className="text-base font-bold text-slate-900 hover:text-indigo-600 truncate block transition-colors"
                    >
                      {candidate.name}
                    </Link>
                    {candidate.jobTitle && (
                      <span className="text-xs text-indigo-600 font-medium flex items-center gap-1 mt-0.5">
                        <Briefcase className="w-3 h-3 shrink-0" />
                        <span className="truncate">{candidate.jobTitle}</span>
                      </span>
                    )}
                  </div>

                  {candidate.screening && (
                    <ScoreBadge score={candidate.screening.matchScore} size="md" />
                  )}
                </div>

                {/* Contact & Experience snippet */}
                <div className="space-y-1 text-xs text-slate-500">
                  {candidate.email && (
                    <div className="flex items-center gap-2 truncate">
                      <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{candidate.email}</span>
                    </div>
                  )}
                  {candidate.phone && (
                    <div className="flex items-center gap-2 truncate">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{candidate.phone}</span>
                    </div>
                  )}
                  <div className="text-[11px] text-slate-400">
                    Experience: {candidate.experienceYears > 0 ? `${candidate.experienceYears}+ years` : 'Not specified'}
                  </div>
                </div>

                {/* Extracted Skills Chips */}
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Extracted Skills
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {candidate.extractedSkills.slice(0, 4).map(skill => (
                      <span
                        key={skill}
                        className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px] font-medium"
                      >
                        {skill}
                      </span>
                    ))}
                    {candidate.extractedSkills.length > 4 && (
                      <span className="px-1.5 py-0.5 rounded-md bg-slate-50 text-slate-400 text-[10px]">
                        +{candidate.extractedSkills.length - 4} more
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Bottom Card Footer */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                {candidate.screening ? (
                  <StatusBadge status={candidate.screening.status} />
                ) : (
                  <span className="text-[11px] text-slate-400">Pending Screening</span>
                )}

                <Link
                  to={`/candidates/${candidate.id}`}
                  className="inline-flex items-center gap-1 text-xs font-bold text-indigo-600 hover:text-indigo-700"
                >
                  <span>Evaluation</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

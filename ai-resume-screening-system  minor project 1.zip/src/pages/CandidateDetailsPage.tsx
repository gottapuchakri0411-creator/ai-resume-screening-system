import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  User,
  Mail,
  Phone,
  Briefcase,
  GraduationCap,
  Calendar,
  FileText,
  Sparkles,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowLeft,
  MessageSquare,
  Plus,
  Trash2,
  Edit2,
  Save,
  X,
  Loader2,
  AlertCircle,
  ShieldCheck,
  Award,
  Mic,
  MicOff
} from 'lucide-react';
import { api } from '../services/api';
import { Candidate, ScreeningResult, Job, Resume, CandidateNote } from '../types';
import { ScoreBadge, StatusBadge } from '../components/ScoreBadge';
import { ResponsibleAIBanner } from '../components/ResponsibleAIBanner';
import { useToast } from '../components/Toast';

export const CandidateDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [candidate, setCandidate] = useState<Candidate | null>(null);
  const [screening, setScreening] = useState<ScreeningResult | null>(null);
  const [job, setJob] = useState<Job | null>(null);
  const [resume, setResume] = useState<Resume | null>(null);
  const [notes, setNotes] = useState<CandidateNote[]>([]);
  const [loading, setLoading] = useState(true);

  // Recruiter Note State
  const [noteContent, setNoteContent] = useState('');
  const [submittingNote, setSubmittingNote] = useState(false);
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');

  // Voice Memo / Transcription state
  const [isRecordingNote, setIsRecordingNote] = useState(false);
  const [isTranscribingNote, setIsTranscribingNote] = useState(false);
  const mediaRecorderRef = React.useRef<MediaRecorder | null>(null);
  const audioChunksRef = React.useRef<Blob[]>([]);

  const startVoiceNoteRecording = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        showToast('Microphone not supported in this browser.', 'error');
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mr = new MediaRecorder(stream);
      mediaRecorderRef.current = mr;

      mr.ondataavailable = e => {
        if (e.data && e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      mr.onstop = async () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        stream.getTracks().forEach(t => t.stop());
        setIsTranscribingNote(true);
        try {
          const res = await api.transcribeAudio(blob);
          if (res && res.transcription) {
            setNoteContent(prev =>
              prev ? `${prev}\n${res.transcription.trim()}` : res.transcription.trim()
            );
            showToast('Voice memo transcribed with gemini-3.5-transcribe!', 'success');
          } else {
            showToast('No speech detected in voice recording.', 'warning');
          }
        } catch (err: any) {
          showToast(`Transcription error: ${err.message}`, 'error');
        } finally {
          setIsTranscribingNote(false);
        }
      };

      mr.start(250);
      setIsRecordingNote(true);
      showToast('Recording voice note... Click again to stop & transcribe.', 'info');
    } catch (err: any) {
      showToast(`Microphone error: ${err.message}`, 'error');
    }
  };

  const stopVoiceNoteRecording = () => {
    if (mediaRecorderRef.current && isRecordingNote) {
      mediaRecorderRef.current.stop();
      setIsRecordingNote(false);
    }
  };

  // Resume text toggle
  const [showFullResume, setShowFullResume] = useState(false);

  useEffect(() => {
    if (id) {
      loadCandidateData(id);
    }
  }, [id]);

  const loadCandidateData = async (candId: string) => {
    setLoading(true);
    try {
      const res = await api.getCandidateDetails(candId);
      setCandidate(res.candidate);
      setScreening(res.screening || null);
      setJob(res.job || null);
      setResume(res.resume || null);
      setNotes(res.notes || []);
    } catch (err: any) {
      showToast(err.message || 'Failed to load candidate details', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (newStatus: any) => {
    if (!screening) return;
    try {
      await api.updateCandidateStatus(screening.id, newStatus);
      setScreening(prev => (prev ? { ...prev, status: newStatus } : null));
      showToast(`Candidate status updated to "${newStatus}"`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to update candidate status', 'error');
    }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!candidate || !noteContent.trim()) return;

    setSubmittingNote(true);
    try {
      const res = await api.addNote(candidate.id, noteContent.trim(), job?.id);
      setNotes(prev => [res.note, ...prev]);
      setNoteContent('');
      showToast('Recruiter note recorded.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to save note', 'error');
    } finally {
      setSubmittingNote(false);
    }
  };

  const handleEditNote = async (noteId: string) => {
    if (!editContent.trim()) return;
    try {
      const res = await api.updateNote(noteId, editContent.trim());
      setNotes(prev => prev.map(n => (n.id === noteId ? res.note : n)));
      setEditingNoteId(null);
      setEditContent('');
      showToast('Note updated.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to update note', 'error');
    }
  };

  const handleDeleteNote = async (noteId: string) => {
    if (!window.confirm('Delete this recruiter note?')) return;
    try {
      await api.deleteNote(noteId);
      setNotes(prev => prev.filter(n => n.id !== noteId));
      showToast('Note deleted.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to delete note', 'error');
    }
  };

  if (loading) {
    return (
      <div className="py-24 flex flex-col items-center justify-center gap-2">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
        <span className="text-xs text-slate-500 font-medium">Loading candidate profile &amp; NLP analysis...</span>
      </div>
    );
  }

  if (!candidate) {
    return (
      <div className="text-center py-20 bg-white rounded-2xl border border-slate-200 p-8">
        <AlertCircle className="w-10 h-10 text-rose-500 mx-auto mb-3" />
        <h3 className="text-base font-bold text-slate-800">Candidate Not Found</h3>
        <p className="text-xs text-slate-500 mt-1 mb-4">This profile does not exist or has been deleted.</p>
        <button
          onClick={() => navigate('/candidates')}
          className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
        >
          Return to Candidates
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <ResponsibleAIBanner compact />

      {/* Top Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-start gap-4">
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors mt-0.5"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 to-blue-500 text-white font-extrabold text-xl flex items-center justify-center shadow-md shadow-indigo-600/20 shrink-0">
            {candidate.name.charAt(0).toUpperCase()}
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-2.5">
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">{candidate.name}</h2>
              {screening && <StatusBadge status={screening.status} />}
            </div>

            <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-xs text-slate-500 mt-1.5">
              {job && (
                <Link
                  to={`/jobs/${job.id}`}
                  className="flex items-center gap-1 font-semibold text-indigo-600 hover:underline"
                >
                  <Briefcase className="w-3.5 h-3.5" />
                  <span>{job.title}</span>
                </Link>
              )}
              {candidate.email && (
                <span className="flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  {candidate.email}
                </span>
              )}
              {candidate.phone && (
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  {candidate.phone}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Status Selector & Overall Score */}
        {screening && (
          <div className="flex items-center gap-4 bg-slate-50 p-3 rounded-2xl border border-slate-100 shrink-0">
            <div className="text-right">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Overall Match
              </span>
              <ScoreBadge score={screening.matchScore} size="lg" showLabel />
            </div>

            <div className="pl-4 border-l border-slate-200">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Recruiter Decision
              </label>
              <select
                value={screening.status}
                onChange={e => handleStatusUpdate(e.target.value)}
                className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-800 shadow-xs focus:outline-hidden cursor-pointer"
              >
                <option value="Shortlisted">Shortlisted</option>
                <option value="Under Review">Under Review</option>
                <option value="Reviewed">Reviewed</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Main Grid: Left = Evaluation Analysis; Right = Notes & Extracted Resume */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Screening Analysis (2 cols) */}
        <div className="lg:col-span-2 space-y-6">
          {screening ? (
            <>
              {/* Score Breakdown Meter */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-slate-900 flex items-center justify-between">
                  <span>Match Score Breakdown</span>
                  <span className="text-xs font-normal text-slate-500">
                    Screened on {new Date(screening.screenedAt).toLocaleDateString()}
                  </span>
                </h3>

                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="p-3.5 rounded-xl bg-indigo-50/60 border border-indigo-100">
                    <span className="text-[11px] font-semibold text-slate-500 block mb-1">
                      Skill Relevancy
                    </span>
                    <span className="text-xl font-extrabold text-indigo-700">{screening.skillScore}%</span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">Required &amp; Preferred</span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-blue-50/60 border border-blue-100">
                    <span className="text-[11px] font-semibold text-slate-500 block mb-1">
                      Semantic / Cosine
                    </span>
                    <span className="text-xl font-extrabold text-blue-700">{screening.semanticScore}%</span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">TF-IDF Vector Sim</span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-purple-50/60 border border-purple-100">
                    <span className="text-[11px] font-semibold text-slate-500 block mb-1">
                      Experience Fit
                    </span>
                    <span className="text-xl font-extrabold text-purple-700">{screening.experienceScore}%</span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">Tenure vs Threshold</span>
                  </div>
                </div>
              </div>

              {/* Skills Matrix: Matched vs Missing */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-slate-900">Competencies &amp; Skills Verification</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Matched Skills */}
                  <div className="p-4 rounded-xl bg-emerald-50/40 border border-emerald-100 space-y-2">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-800">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Matched Skills ({screening.matchedSkills.length})</span>
                    </div>
                    {screening.matchedSkills.length === 0 ? (
                      <p className="text-xs text-slate-400 italic">No direct skill matches detected.</p>
                    ) : (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {screening.matchedSkills.map(skill => (
                          <span
                            key={skill}
                            className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-semibold"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Missing Skills */}
                  <div className="p-4 rounded-xl bg-rose-50/40 border border-rose-100 space-y-2">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-rose-800">
                      <XCircle className="w-4 h-4 text-rose-600" />
                      <span>Missing Required Skills ({screening.missingSkills.length})</span>
                    </div>
                    {screening.missingSkills.length === 0 ? (
                      <p className="text-xs text-emerald-700 font-medium">
                        All mandatory technical requirements identified.
                      </p>
                    ) : (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {screening.missingSkills.map(skill => (
                          <span
                            key={skill}
                            className="px-2.5 py-1 rounded-lg bg-rose-100 text-rose-800 text-xs font-semibold"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* AI & NLP Explanation */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
                <div className="flex items-center gap-2 text-indigo-600">
                  <Sparkles className="w-5 h-5" />
                  <h3 className="text-sm font-bold text-slate-900">AI Semantic Screening Explanation</h3>
                </div>
                <div className="p-4 rounded-xl bg-indigo-50/50 border border-indigo-100 text-xs text-slate-700 leading-relaxed font-medium">
                  {screening.explanation}
                </div>

                {/* Experience & Education Relevance Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                      Experience Relevance
                    </span>
                    <p className="text-xs text-slate-700 leading-relaxed">
                      {screening.relevantExperience}
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                      Education Relevance
                    </span>
                    <p className="text-xs text-slate-700 leading-relaxed">
                      {screening.educationRelevance}
                    </p>
                  </div>
                </div>

                {/* Requirements Checklist */}
                {(screening.satisfiedRequirements.length > 0 || screening.missingRequirements.length > 0) && (
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    <span className="text-xs font-bold text-slate-700 block">Requirements Analysis Checklist</span>
                    <div className="space-y-1.5">
                      {screening.satisfiedRequirements.map((req, i) => (
                        <div key={i} className="flex items-start gap-2 text-xs text-slate-700">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{req}</span>
                        </div>
                      ))}
                      {screening.missingRequirements.map((req, i) => (
                        <div key={i} className="flex items-start gap-2 text-xs text-slate-500">
                          <XCircle className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
                          <span>{req}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="p-8 bg-white rounded-2xl border border-slate-200 text-center">
              <Clock className="w-8 h-8 text-amber-500 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-slate-800">Pending Screening</h3>
              <p className="text-xs text-slate-500 mt-1">This candidate resume is queued for automated screening.</p>
            </div>
          )}

          {/* Extracted Resume Text Card */}
          {resume && (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Extracted Resume Content</h3>
                  <p className="text-xs text-slate-500">Source: {resume.originalName}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowFullResume(!showFullResume)}
                  className="text-xs font-bold text-indigo-600 hover:underline"
                >
                  {showFullResume ? 'Collapse Text' : 'View Full Extracted Text'}
                </button>
              </div>

              <div
                className={`p-4 rounded-xl bg-slate-50 border border-slate-100 font-mono text-xs text-slate-700 whitespace-pre-wrap leading-relaxed overflow-y-auto ${
                  showFullResume ? 'max-h-[600px]' : 'max-h-48'
                }`}
              >
                {resume.extractedText || 'No extracted text found in resume.'}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Recruiter Notes & Actions (1 col) */}
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-indigo-600" />
                <h3 className="text-sm font-bold text-slate-900">Private Recruiter Notes</h3>
              </div>
              <span className="text-[11px] text-slate-400 font-semibold">{notes.length} note(s)</span>
            </div>

            {/* Add Note Form */}
            <form onSubmit={handleAddNote} className="space-y-2">
              <textarea
                rows={3}
                value={noteContent}
                onChange={e => setNoteContent(e.target.value)}
                placeholder="Add confidential evaluation feedback, interview notes, or candidate remarks..."
                required
                className="w-full p-3 rounded-xl border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-indigo-500"
              />
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={isRecordingNote ? stopVoiceNoteRecording : startVoiceNoteRecording}
                  disabled={isTranscribingNote}
                  className={`flex-1 py-2 px-3 rounded-xl border text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                    isRecordingNote
                      ? 'bg-rose-500 hover:bg-rose-600 text-white border-rose-600 animate-pulse'
                      : 'bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-200 text-slate-700 border-slate-200'
                  }`}
                  title={isRecordingNote ? 'Click to stop & transcribe' : 'Dictate note with microphone using gemini-3.5-transcribe'}
                >
                  {isTranscribingNote ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Transcribing...</span>
                    </>
                  ) : isRecordingNote ? (
                    <>
                      <MicOff className="w-3.5 h-3.5" />
                      <span>Stop & Transcribe</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Dictate Note</span>
                    </>
                  )}
                </button>

                <button
                  type="submit"
                  disabled={submittingNote || !noteContent.trim() || isRecordingNote}
                  className="flex-1 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold shadow-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  {submittingNote ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" />
                      <span>Save Note</span>
                    </>
                  )}
                </button>
              </div>
            </form>

            {/* Notes List */}
            <div className="space-y-3 pt-2">
              {notes.length === 0 ? (
                <div className="text-center py-6 text-xs text-slate-400">
                  No recruiter notes recorded for this candidate yet.
                </div>
              ) : (
                notes.map(note => (
                  <div
                    key={note.id}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold text-slate-800">{note.recruiterName}</span>
                      <div className="flex items-center gap-1.5 text-slate-400">
                        <span>{new Date(note.createdAt).toLocaleDateString()}</span>
                        <button
                          onClick={() => {
                            setEditingNoteId(note.id);
                            setEditContent(note.content);
                          }}
                          className="hover:text-indigo-600 p-0.5"
                          title="Edit"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => handleDeleteNote(note.id)}
                          className="hover:text-rose-600 p-0.5"
                          title="Delete"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    {editingNoteId === note.id ? (
                      <div className="space-y-2 pt-1">
                        <textarea
                          rows={2}
                          value={editContent}
                          onChange={e => setEditContent(e.target.value)}
                          className="w-full p-2 rounded-lg border border-slate-300 text-xs text-slate-900 bg-white"
                        />
                        <div className="flex justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => setEditingNoteId(null)}
                            className="px-2 py-1 rounded text-[10px] text-slate-500 hover:bg-slate-200"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={() => handleEditNote(note.id)}
                            className="px-2.5 py-1 rounded bg-indigo-600 text-white text-[10px] font-semibold"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    ) : (
                      <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">{note.content}</p>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

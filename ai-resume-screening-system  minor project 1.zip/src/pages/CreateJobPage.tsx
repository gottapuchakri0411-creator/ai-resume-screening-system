import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Briefcase,
  Building,
  MapPin,
  Calendar,
  Sparkles,
  ArrowLeft,
  Plus,
  X,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Mic,
  MicOff
} from 'lucide-react';
import { api } from '../services/api';
import { useToast } from '../components/Toast';
import { useAuth } from '../context/AuthContext';

export const CreateJobPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [title, setTitle] = useState('');
  const [company, setCompany] = useState(user?.company || 'Apex Tech Solutions');
  const [department, setDepartment] = useState('Engineering');
  const [location, setLocation] = useState('San Francisco, CA (Hybrid)');
  const [employmentType, setEmploymentType] = useState<'Full-time' | 'Part-time' | 'Contract' | 'Remote' | 'Internship'>('Full-time');
  const [minimumExperience, setMinimumExperience] = useState(3);
  const [educationRequirements, setEducationRequirements] = useState("Bachelor's degree in Computer Science, Engineering, or equivalent experience");
  const [description, setDescription] = useState('');

  // Skill tags
  const [requiredSkills, setRequiredSkills] = useState<string[]>(['React', 'TypeScript', 'Node.js']);
  const [skillInput, setSkillInput] = useState('');

  const [preferredSkills, setPreferredSkills] = useState<string[]>(['Docker', 'PostgreSQL', 'AWS']);
  const [prefSkillInput, setPrefSkillInput] = useState('');

  const [status, setStatus] = useState<'Active' | 'Draft'>('Active');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Voice Dictation state for Job Description
  const [isRecordingDesc, setIsRecordingDesc] = useState(false);
  const [isTranscribingDesc, setIsTranscribingDesc] = useState(false);
  const mediaRecorderRef = React.useRef<MediaRecorder | null>(null);
  const audioChunksRef = React.useRef<Blob[]>([]);

  const startDescRecording = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        showToast('Microphone not supported in this browser.', 'error');
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mr = new MediaRecorder(stream);
      mediaRecorderRef.current = mr;

      mr.ondataavailable = e => {
        if (e.data && e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      mr.onstop = async () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        stream.getTracks().forEach(t => t.stop());
        setIsTranscribingDesc(true);
        try {
          const res = await api.transcribeAudio(blob);
          if (res && res.transcription) {
            setDescription(prev =>
              prev ? `${prev}\n\n${res.transcription.trim()}` : res.transcription.trim()
            );
            showToast('Voice dictation transcribed into job description!', 'success');
          } else {
            showToast('No speech detected in audio.', 'warning');
          }
        } catch (err: any) {
          showToast(`Transcription error: ${err.message}`, 'error');
        } finally {
          setIsTranscribingDesc(false);
        }
      };

      mr.start(250);
      setIsRecordingDesc(true);
      showToast('Recording job requirements... Click again to stop & transcribe.', 'info');
    } catch (err: any) {
      showToast(`Microphone error: ${err.message}`, 'error');
    }
  };

  const stopDescRecording = () => {
    if (mediaRecorderRef.current && isRecordingDesc) {
      mediaRecorderRef.current.stop();
      setIsRecordingDesc(false);
    }
  };

  const handleAddRequiredSkill = (e: React.KeyboardEvent | React.MouseEvent) => {
    if ('key' in e && e.key !== 'Enter') return;
    e.preventDefault();
    const clean = skillInput.trim();
    if (clean && !requiredSkills.includes(clean)) {
      setRequiredSkills(prev => [...prev, clean]);
      setSkillInput('');
    }
  };

  const handleRemoveRequiredSkill = (skill: string) => {
    setRequiredSkills(prev => prev.filter(s => s !== skill));
  };

  const handleAddPrefSkill = (e: React.KeyboardEvent | React.MouseEvent) => {
    if ('key' in e && e.key !== 'Enter') return;
    e.preventDefault();
    const clean = prefSkillInput.trim();
    if (clean && !preferredSkills.includes(clean)) {
      setPreferredSkills(prev => [...prev, clean]);
      setPrefSkillInput('');
    }
  };

  const handleRemovePrefSkill = (skill: string) => {
    setPreferredSkills(prev => prev.filter(s => s !== skill));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg('Please specify the Job Title.');
      return;
    }
    if (!description.trim()) {
      setErrorMsg('Please enter the full Job Description. It serves as the baseline for AI semantic screening.');
      return;
    }
    if (requiredSkills.length === 0) {
      setErrorMsg('Please add at least one Required Technical Skill.');
      return;
    }

    setLoading(true);
    setErrorMsg(null);

    try {
      const res = await api.createJob({
        title: title.trim(),
        company: company.trim(),
        department: department.trim(),
        location: location.trim(),
        employmentType,
        minimumExperience: Number(minimumExperience),
        educationRequirements: educationRequirements.trim(),
        description: description.trim(),
        requiredSkills,
        preferredSkills,
        status
      });

      showToast(`Position "${res.job.title}" created successfully!`, 'success');
      navigate(`/jobs/${res.job.id}`);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to create job posting.');
      showToast(err.message || 'Error creating job', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Top back bar */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => navigate('/jobs')}
          className="p-2 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-200/60 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Post New Position</h2>
          <p className="text-xs text-slate-500">
            Define requirements against which resumes will be evaluated using NLP and semantic AI
          </p>
        </div>
      </div>

      {errorMsg && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 sm:p-8 space-y-6">
        {/* Core Job Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="md:col-span-2">
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5">
              Job Title *
            </label>
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="e.g. Senior Machine Learning Engineer"
              required
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5">
              Company Name
            </label>
            <input
              type="text"
              value={company}
              onChange={e => setCompany(e.target.value)}
              placeholder="e.g. Apex Tech Solutions"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5">
              Department / Team
            </label>
            <input
              type="text"
              value={department}
              onChange={e => setDepartment(e.target.value)}
              placeholder="e.g. Platform Infrastructure"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5">
              Workplace Location
            </label>
            <input
              type="text"
              value={location}
              onChange={e => setLocation(e.target.value)}
              placeholder="e.g. San Francisco, CA or Remote"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5">
              Employment Type
            </label>
            <select
              value={employmentType}
              onChange={e => setEmploymentType(e.target.value as any)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500 bg-white"
            >
              <option value="Full-time">Full-time</option>
              <option value="Part-time">Part-time</option>
              <option value="Contract">Contract</option>
              <option value="Remote">Remote</option>
              <option value="Internship">Internship</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5">
              Minimum Experience (Years)
            </label>
            <input
              type="number"
              min={0}
              max={30}
              value={minimumExperience}
              onChange={e => setMinimumExperience(parseInt(e.target.value, 10) || 0)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5">
              Posting Status
            </label>
            <select
              value={status}
              onChange={e => setStatus(e.target.value as any)}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500 bg-white"
            >
              <option value="Active">Active (Intake open)</option>
              <option value="Draft">Draft (Internal review)</option>
            </select>
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5">
              Education Requirements
            </label>
            <input
              type="text"
              value={educationRequirements}
              onChange={e => setEducationRequirements(e.target.value)}
              placeholder="e.g. Bachelor's in CS, Data Science, or equivalent practical experience"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Required Skills Tags */}
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
            Required Technical &amp; Role Skills *
          </label>
          <p className="text-xs text-slate-500">
            Skills that candidates MUST have. These are matched with highest weight in the scoring algorithm.
          </p>

          <div className="flex flex-wrap items-center gap-2 p-3 rounded-xl border border-slate-200 bg-slate-50/60 min-h-[48px]">
            {requiredSkills.map(skill => (
              <span
                key={skill}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-600 text-white text-xs font-semibold shadow-xs"
              >
                <span>{skill}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveRequiredSkill(skill)}
                  className="hover:text-indigo-200"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </span>
            ))}

            <div className="flex items-center gap-1.5 flex-1 min-w-[150px]">
              <input
                type="text"
                value={skillInput}
                onChange={e => setSkillInput(e.target.value)}
                onKeyDown={handleAddRequiredSkill}
                placeholder="Type skill & press Enter (e.g. Python, SQL, Docker)..."
                className="w-full bg-transparent text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden py-1"
              />
              <button
                type="button"
                onClick={handleAddRequiredSkill}
                className="p-1 rounded-md text-indigo-600 hover:bg-indigo-100 shrink-0"
                title="Add skill"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Preferred Skills Tags */}
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
            Preferred / Nice-to-Have Skills
          </label>
          <p className="text-xs text-slate-500">
            Bonus skills that boost candidate ranking if found on the resume.
          </p>

          <div className="flex flex-wrap items-center gap-2 p-3 rounded-xl border border-slate-200 bg-slate-50/60 min-h-[48px]">
            {preferredSkills.map(skill => (
              <span
                key={skill}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-200 text-slate-800 text-xs font-semibold"
              >
                <span>{skill}</span>
                <button
                  type="button"
                  onClick={() => handleRemovePrefSkill(skill)}
                  className="hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </span>
            ))}

            <div className="flex items-center gap-1.5 flex-1 min-w-[150px]">
              <input
                type="text"
                value={prefSkillInput}
                onChange={e => setPrefSkillInput(e.target.value)}
                onKeyDown={handleAddPrefSkill}
                placeholder="Type preferred skill & press Enter..."
                className="w-full bg-transparent text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden py-1"
              />
              <button
                type="button"
                onClick={handleAddPrefSkill}
                className="p-1 rounded-md text-slate-600 hover:bg-slate-200 shrink-0"
                title="Add skill"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Full Job Description */}
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
              Job Description &amp; Responsibilities *
            </label>
            <button
              type="button"
              onClick={isRecordingDesc ? stopDescRecording : startDescRecording}
              disabled={isTranscribingDesc}
              className={`px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all flex items-center gap-1.5 ${
                isRecordingDesc
                  ? 'bg-rose-500 hover:bg-rose-600 text-white border-rose-600 animate-pulse'
                  : 'bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-200 text-slate-700 border-slate-200'
              }`}
              title={isRecordingDesc ? 'Click to stop & transcribe' : 'Dictate requirements with microphone via gemini-3.5-transcribe'}
            >
              {isTranscribingDesc ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Transcribing speech...</span>
                </>
              ) : isRecordingDesc ? (
                <>
                  <MicOff className="w-3.5 h-3.5" />
                  <span>Stop &amp; Transcribe</span>
                </>
              ) : (
                <>
                  <Mic className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Dictate with Microphone</span>
                </>
              )}
            </button>
          </div>
          <p className="text-xs text-slate-500">
            This full text is the primary semantic reference utilized for TF-IDF cosine comparison and Gemini AI context matching.
          </p>
          <textarea
            rows={8}
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="Paste comprehensive job description including core responsibilities, day-to-day duties, technical tech stack, team structure, and qualifications..."
            required
            className="w-full p-4 rounded-xl border border-slate-200 text-xs text-slate-900 leading-relaxed font-mono focus:outline-hidden focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        {/* Submit Bar */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
          <button
            type="button"
            onClick={() => navigate('/jobs')}
            disabled={loading}
            className="px-5 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition-all"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Publishing Job...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Create &amp; Upload Resumes</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

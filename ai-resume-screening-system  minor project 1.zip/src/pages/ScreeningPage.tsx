import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  Sparkles,
  Search,
  Filter,
  ArrowUpDown,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  FileText,
  User,
  ShieldCheck,
  Loader2,
  Briefcase,
  ChevronDown
} from 'lucide-react';
import { api } from '../services/api';
import { Job, RankedCandidate } from '../types';
import { ScoreBadge, StatusBadge } from '../components/ScoreBadge';
import { ResponsibleAIBanner } from '../components/ResponsibleAIBanner';
import { useToast } from '../components/Toast';
import { EmptyState } from '../components/EmptyState';

export const ScreeningPage: React.FC = () => {
  const { jobId } = useParams<{ jobId: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [jobs, setJobs] = useState<Job[]>([]);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [candidates, setCandidates] = useState<RankedCandidate[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters & Sorting
  const [searchQuery, setSearchQuery] = useState('');
  const [scoreFilter, setScoreFilter] = useState<number>(0);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [skillFilter, setSkillFilter] = useState<string>('ALL');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  useEffect(() => {
    initJobs();
  }, [jobId]);

  const initJobs = async () => {
    setLoading(true);
    try {
      const jobsRes = await api.getJobs();
      setJobs(jobsRes.jobs);

      let targetJobId = jobId;
      if (!targetJobId || targetJobId === 'latest') {
        if (jobsRes.jobs.length > 0) {
          targetJobId = jobsRes.jobs[0].id;
        }
      }

      if (targetJobId) {
        await loadScreening(targetJobId);
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to load screening data', 'error');
    } finally {
      setLoading(false);
    }
  };

  const loadScreening = async (targetJobId: string) => {
    setLoading(true);
    try {
      const res = await api.getScreeningResults(targetJobId);
      setSelectedJob(res.job);
      setCandidates(res.rankedCandidates);
    } catch (err: any) {
      showToast(err.message || 'Failed to load candidate rankings', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (candidate: RankedCandidate, newStatus: any) => {
    try {
      await api.updateCandidateStatus(candidate.id, newStatus);
      setCandidates(prev =>
        prev.map(c => (c.id === candidate.id ? { ...c, status: newStatus } : c))
      );
      showToast(`Updated ${candidate.candidateName} status to "${newStatus}"`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to update candidate status', 'error');
    }
  };

  // Unique skills across candidates
  const allMatchedSkills = Array.from(
    new Set(candidates.flatMap(c => c.matchedSkills))
  ).sort();

  // Filter & sort logic
  const filteredCandidates = candidates
    .filter(c => {
      const matchesSearch =
        c.candidateName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.matchedSkills.some(s => s.toLowerCase().includes(searchQuery.toLowerCase())) ||
        c.explanation.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesScore = c.matchScore >= scoreFilter;
      const matchesStatus = statusFilter === 'ALL' || c.status === statusFilter;
      const matchesSkill = skillFilter === 'ALL' || c.matchedSkills.includes(skillFilter);

      return matchesSearch && matchesScore && matchesStatus && matchesSkill;
    })
    .sort((a, b) => {
      if (sortOrder === 'desc') return b.matchScore - a.matchScore;
      return a.matchScore - b.matchScore;
    });

  return (
    <div className="space-y-6">
      <ResponsibleAIBanner />

      {/* Position Header & Switcher */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100">
              Screening Results &amp; Ranking
            </span>
            {selectedJob && <StatusBadge status={selectedJob.status} />}
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            {selectedJob ? selectedJob.title : 'Select a Job Opening'}
          </h2>
          {selectedJob && (
            <p className="text-xs text-slate-500 mt-0.5">
              {selectedJob.company} • {candidates.length} candidate(s) screened against baseline criteria
            </p>
          )}
        </div>

        {/* Job Switcher Dropdown */}
        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-500 font-semibold shrink-0">Switch Job:</label>
          <select
            value={selectedJob?.id || ''}
            onChange={e => {
              navigate(`/screening/${e.target.value}`);
              loadScreening(e.target.value);
            }}
            className="px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 focus:outline-hidden focus:border-indigo-500 max-w-xs truncate"
          >
            {jobs.map(j => (
              <option key={j.id} value={j.id}>
                {j.title} ({j.department})
              </option>
            ))}
          </select>

          {selectedJob && (
            <Link
              to={`/jobs/${selectedJob.id}`}
              className="px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700"
            >
              Job Specs
            </Link>
          )}
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search candidate by name, extracted skill, or keyword..."
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400 text-xs focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            {/* Score Tier Filter */}
            <select
              value={scoreFilter}
              onChange={e => setScoreFilter(Number(e.target.value))}
              className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-800 focus:outline-hidden"
            >
              <option value={0}>All Scores (0%+)</option>
              <option value={80}>Top Tier (&ge; 80%)</option>
              <option value={60}>Moderate+ (&ge; 60%)</option>
              <option value={45}>Reviewable (&ge; 45%)</option>
            </select>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-800 focus:outline-hidden"
            >
              <option value="ALL">All Decision Statuses</option>
              <option value="Shortlisted">Shortlisted</option>
              <option value="Under Review">Under Review</option>
              <option value="Reviewed">Reviewed</option>
              <option value="Rejected">Rejected</option>
            </select>

            {/* Skill Filter */}
            {allMatchedSkills.length > 0 && (
              <select
                value={skillFilter}
                onChange={e => setSkillFilter(e.target.value)}
                className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-800 focus:outline-hidden max-w-[140px] truncate"
              >
                <option value="ALL">All Skills</option>
                {allMatchedSkills.map(s => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            )}

            {/* Sort Toggle */}
            <button
              onClick={() => setSortOrder(prev => (prev === 'desc' ? 'asc' : 'desc'))}
              className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 hover:bg-slate-100 text-xs font-semibold text-slate-700 flex items-center gap-1.5"
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span>Score: {sortOrder === 'desc' ? 'High &rarr; Low' : 'Low &rarr; High'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Candidate Ranking Table */}
      {loading ? (
        <div className="py-20 flex flex-col items-center justify-center gap-2">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
          <span className="text-xs text-slate-500 font-medium">Computing and ranking candidate profiles...</span>
        </div>
      ) : filteredCandidates.length === 0 ? (
        <EmptyState
          icon={User}
          title="No Candidates Found"
          description={
            candidates.length === 0
              ? 'No resumes have been screened for this position yet. Upload resumes and run the screening pipeline.'
              : 'No candidate matches the currently selected filter conditions.'
          }
          actionText={candidates.length === 0 ? 'Upload & Screen Resumes' : 'Reset Filters'}
          onAction={
            candidates.length === 0
              ? () => selectedJob && navigate(`/jobs/${selectedJob.id}`)
              : () => {
                  setSearchQuery('');
                  setScoreFilter(0);
                  setStatusFilter('ALL');
                  setSkillFilter('ALL');
                }
          }
        />
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  <th className="py-3.5 px-4">Rank</th>
                  <th className="py-3.5 px-4">Candidate &amp; Resume</th>
                  <th className="py-3.5 px-4 text-center">Match Score</th>
                  <th className="py-3.5 px-4">Matched Skills</th>
                  <th className="py-3.5 px-4">Missing Skills</th>
                  <th className="py-3.5 px-4">AI / NLP Analysis Summary</th>
                  <th className="py-3.5 px-4">Decision Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredCandidates.map((c, index) => (
                  <tr key={c.id} className="hover:bg-slate-50/60 transition-colors">
                    {/* Rank Number */}
                    <td className="py-4 px-4 font-bold text-slate-400">
                      <span className="w-6 h-6 rounded-md bg-slate-100 flex items-center justify-center text-slate-700 text-xs">
                        #{index + 1}
                      </span>
                    </td>

                    {/* Candidate */}
                    <td className="py-4 px-4 min-w-[180px]">
                      <Link
                        to={`/candidates/${c.candidateId}`}
                        className="font-bold text-slate-900 hover:text-indigo-600 block transition-colors"
                      >
                        {c.candidateName}
                      </Link>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                        <FileText className="w-3 h-3 shrink-0" />
                        <span className="truncate max-w-[140px]">{c.resumeFilename}</span>
                      </div>
                    </td>

                    {/* Score */}
                    <td className="py-4 px-4 text-center whitespace-nowrap">
                      <ScoreBadge score={c.matchScore} size="md" showLabel />
                      <div className="text-[10px] text-slate-400 mt-1">
                        Skills: {c.skillScore}% • Sem: {c.semanticScore}%
                      </div>
                    </td>

                    {/* Matched Skills */}
                    <td className="py-4 px-4 max-w-[200px]">
                      <div className="flex flex-wrap gap-1">
                        {c.matchedSkills.slice(0, 3).map(skill => (
                          <span
                            key={skill}
                            className="px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-100 text-emerald-700 text-[10px] font-semibold"
                          >
                            {skill}
                          </span>
                        ))}
                        {c.matchedSkills.length > 3 && (
                          <span className="px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-500 text-[10px]">
                            +{c.matchedSkills.length - 3}
                          </span>
                        )}
                        {c.matchedSkills.length === 0 && (
                          <span className="text-[11px] text-slate-400 italic">None matched</span>
                        )}
                      </div>
                    </td>

                    {/* Missing Skills */}
                    <td className="py-4 px-4 max-w-[180px]">
                      <div className="flex flex-wrap gap-1">
                        {c.missingSkills.slice(0, 2).map(skill => (
                          <span
                            key={skill}
                            className="px-2 py-0.5 rounded-md bg-rose-50 border border-rose-100 text-rose-700 text-[10px] font-medium"
                          >
                            {skill}
                          </span>
                        ))}
                        {c.missingSkills.length > 2 && (
                          <span className="px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-500 text-[10px]">
                            +{c.missingSkills.length - 2}
                          </span>
                        )}
                        {c.missingSkills.length === 0 && (
                          <span className="text-[11px] text-emerald-600 font-medium">All matched</span>
                        )}
                      </div>
                    </td>

                    {/* AI Explanation snippet */}
                    <td className="py-4 px-4 max-w-[260px]">
                      <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed">
                        {c.explanation}
                      </p>
                    </td>

                    {/* Decision Status Dropdown */}
                    <td className="py-4 px-4 whitespace-nowrap">
                      <select
                        value={c.status}
                        onChange={e => handleStatusChange(c, e.target.value)}
                        className={`text-xs font-semibold px-2.5 py-1 rounded-lg border focus:outline-hidden cursor-pointer ${
                          c.status === 'Shortlisted'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : c.status === 'Under Review'
                            ? 'bg-blue-50 text-blue-800 border-blue-200'
                            : c.status === 'Reviewed'
                            ? 'bg-slate-100 text-slate-800 border-slate-200'
                            : 'bg-rose-50 text-rose-800 border-rose-200'
                        }`}
                      >
                        <option value="Shortlisted">Shortlisted</option>
                        <option value="Under Review">Under Review</option>
                        <option value="Reviewed">Reviewed</option>
                        <option value="Rejected">Rejected</option>
                      </select>
                    </td>

                    {/* Actions */}
                    <td className="py-4 px-4 text-right whitespace-nowrap">
                      <Link
                        to={`/candidates/${c.candidateId}`}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold transition-colors"
                      >
                        <span>Details</span>
                        <ExternalLink className="w-3 h-3" />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-4 border-t border-slate-100 bg-slate-50/60 flex items-center justify-between text-xs text-slate-500">
            <span>
              Showing {filteredCandidates.length} of {candidates.length} ranked candidates
            </span>
            <span>
              Recruiter is the final decision-maker. Scores are decision-support insights.
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

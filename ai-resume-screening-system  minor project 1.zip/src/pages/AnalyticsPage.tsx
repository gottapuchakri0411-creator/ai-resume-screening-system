import React, { useState, useEffect } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import {
  BarChart3,
  Award,
  Users,
  Briefcase,
  FileText,
  AlertTriangle,
  Sparkles,
  Loader2,
  TrendingUp,
  ShieldCheck
} from 'lucide-react';
import { api } from '../services/api';
import { AnalyticsData } from '../types';
import { EmptyState } from '../components/EmptyState';
import { ResponsibleAIBanner } from '../components/ResponsibleAIBanner';

const SCORE_COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#f97316', '#ef4444'];

export const AnalyticsPage: React.FC = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    setLoading(true);
    try {
      const res = await api.getAnalytics();
      setAnalytics(res.analytics);
    } catch (err: any) {
      console.error('Failed to load analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="py-24 flex flex-col items-center justify-center gap-2">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
        <span className="text-xs text-slate-500 font-medium">Aggregating screening intelligence &amp; charts...</span>
      </div>
    );
  }

  const hasData = analytics && (analytics.totalResumes > 0 || analytics.totalJobs > 0);

  return (
    <div className="space-y-6">
      <ResponsibleAIBanner />

      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">Screening Analytics &amp; Talent Insights</h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Quantified metrics evaluating applicant relevance distributions, skill frequencies, and competency gaps
        </p>
      </div>

      {!hasData ? (
        <EmptyState
          icon={BarChart3}
          title="No Screening Data Available"
          description="Upload resumes to your job postings and run screenings to view analytics and skill distributions."
        />
      ) : (
        <>
          {/* Summary Metric Strip */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Resumes Processed
              </span>
              <div className="text-2xl font-black text-slate-900">{analytics.processedResumes}</div>
              <span className="text-[11px] text-slate-500 mt-1 block">
                Out of {analytics.totalResumes} uploaded
              </span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Average Match Score
              </span>
              <div className="text-2xl font-black text-emerald-600">{analytics.averageMatchScore}%</div>
              <span className="text-[11px] text-slate-500 mt-1 block">
                Across screened applicants
              </span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Active Job Openings
              </span>
              <div className="text-2xl font-black text-indigo-600">{analytics.activeJobs}</div>
              <span className="text-[11px] text-slate-500 mt-1 block">
                {analytics.totalJobs} total positions
              </span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Pending Review
              </span>
              <div className="text-2xl font-black text-amber-600">{analytics.candidatesRequiringReview}</div>
              <span className="text-[11px] text-slate-500 mt-1 block">
                Awaiting recruiter decision
              </span>
            </div>
          </div>

          {/* First Chart Row: Score Distribution & Candidates Per Job */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Score Distribution */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
              <div className="mb-4">
                <h3 className="text-sm font-bold text-slate-900">Score Range Distribution</h3>
                <p className="text-xs text-slate-500">Applicant qualification clustering across all jobs</p>
              </div>

              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={analytics.scoreDistribution} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="range" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} allowDecimals={false} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                    />
                    <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                      {analytics.scoreDistribution.map((_entry, index) => (
                        <Cell key={`cell-${index}`} fill={SCORE_COLORS[index % SCORE_COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Candidates Per Job */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
              <div className="mb-4">
                <h3 className="text-sm font-bold text-slate-900">Candidate Volume Per Job</h3>
                <p className="text-xs text-slate-500">Screened applicants by job opening</p>
              </div>

              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={analytics.candidatesPerJob} layout="vertical" margin={{ top: 10, right: 20, left: 10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                    <XAxis type="number" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} allowDecimals={false} />
                    <YAxis dataKey="jobTitle" type="category" width={110} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                    />
                    <Bar dataKey="count" fill="#4f46e5" radius={[0, 6, 6, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Second Chart Row: Matched Skills vs Missing Skills Gap Analysis */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top Matched Skills */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
              <div className="mb-4">
                <h3 className="text-sm font-bold text-slate-900">Top Verified Candidate Skills</h3>
                <p className="text-xs text-slate-500">Most frequent technical proficiencies found in resumes</p>
              </div>

              {analytics.topSkills.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-xs text-slate-400">
                  No skills matched yet.
                </div>
              ) : (
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analytics.topSkills} layout="vertical" margin={{ top: 10, right: 20, left: 10, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                      <XAxis type="number" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} allowDecimals={false} />
                      <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                      />
                      <Bar dataKey="count" fill="#10b981" radius={[0, 6, 6, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            {/* Top Missing Skills */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
              <div className="mb-4">
                <h3 className="text-sm font-bold text-slate-900">Competency Gap Analysis</h3>
                <p className="text-xs text-slate-500">Required skills most frequently absent from applicant resumes</p>
              </div>

              {analytics.topMissingSkills.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-xs text-slate-400">
                  No missing skill gaps detected.
                </div>
              ) : (
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analytics.topMissingSkills} layout="vertical" margin={{ top: 10, right: 20, left: 10, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                      <XAxis type="number" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} allowDecimals={false} />
                      <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#0f172a', borderRadius: '12px', border: 'none', color: '#fff', fontSize: '12px' }}
                      />
                      <Bar dataKey="count" fill="#f43f5e" radius={[0, 6, 6, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

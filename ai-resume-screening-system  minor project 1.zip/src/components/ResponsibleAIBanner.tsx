import React, { useState } from 'react';
import { ShieldCheck, Info, X } from 'lucide-react';

export const ResponsibleAIBanner: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  if (compact) {
    return (
      <div className="flex items-center justify-between gap-3 px-3 py-2 rounded-xl bg-indigo-50/80 border border-indigo-100 text-xs text-indigo-900">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-indigo-600 shrink-0" />
          <span>
            <strong>Decision-Support AI:</strong> Scoring is based exclusively on job-relevant skills and experience. Protected traits are omitted. The recruiter retains final hiring authority.
          </span>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="text-indigo-400 hover:text-indigo-700 transition-colors shrink-0"
          aria-label="Dismiss banner"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  return (
    <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-50/90 via-slate-50 to-blue-50/70 border border-indigo-100/80 shadow-xs mb-6 relative">
      <div className="flex items-start gap-3.5">
        <div className="w-8 h-8 rounded-xl bg-indigo-600/10 text-indigo-600 flex items-center justify-center shrink-0 mt-0.5">
          <ShieldCheck className="w-5 h-5" />
        </div>
        <div className="flex-1 pr-6">
          <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-900 mb-1 flex items-center gap-1.5">
            Responsible AI &amp; Ethical Screening Charter
          </h4>
          <p className="text-xs text-slate-600 leading-relaxed">
            This system operates strictly under <strong>Decision-Support Guidance</strong>. Candidate evaluations are derived from objective text extraction of required competencies, technical skills, and professional experience. Demographic characteristics (including gender, race, age, religion, disability, or marital status) are excluded from scoring calculations. Recruiters remain the final human decision-makers.
          </p>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="absolute top-3.5 right-3.5 text-slate-400 hover:text-slate-600 transition-colors"
          aria-label="Dismiss banner"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import {
  Sparkles,
  X,
  Send,
  Loader2,
  Globe,
  Bot,
  User,
  Trash2,
  Mic,
  MicOff,
  Briefcase,
  HelpCircle,
  ExternalLink,
  ChevronRight,
  Zap,
  Brain
} from 'lucide-react';
import { api } from '../services/api';
import { useToast } from './Toast';

interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
  searchSources?: { title?: string; uri?: string }[];
}

interface RecruiterCopilotDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeCandidateId?: string;
  activeJobId?: string;
  activeCandidateName?: string;
  activeJobTitle?: string;
}

export const RecruiterCopilotDrawer: React.FC<RecruiterCopilotDrawerProps> = ({
  isOpen,
  onClose,
  activeCandidateId,
  activeJobId,
  activeCandidateName,
  activeJobTitle,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'model',
      content:
        'Hello! I am your **AI Recruitment Copilot & Screening Advisor** powered by Gemini. How can I assist you with candidate evaluation, skill gap breakdown, interview formulation, or market benchmarking today?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [useSearch, setUseSearch] = useState(false);
  const [modelSpeed, setModelSpeed] = useState<'fast' | 'general' | 'deep'>('general');
  const [isRecording, setIsRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const { showToast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || loading) return;

    const userMessage: Message = {
      id: `usr_${Date.now()}`,
      role: 'user',
      content: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMessage];
    setMessages(newHistory);
    setInput('');
    setLoading(true);

    try {
      // Format messages payload for server
      const serverMessages = newHistory
        .filter(m => m.id !== 'welcome')
        .map(m => ({ role: m.role, content: m.content }));

      const res = await api.sendCopilotMessage({
        messages: serverMessages,
        candidateId: activeCandidateId,
        jobId: activeJobId,
        useSearch,
        modelSpeed,
      });

      const aiMessage: Message = {
        id: `model_${Date.now()}`,
        role: 'model',
        content: res.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        searchSources: res.searchSources,
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (err: any) {
      showToast(err.message || 'AI Copilot encountered an error.', 'error');
      setMessages(prev => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          role: 'model',
          content: `⚠️ Error: ${err.message || 'Failed to generate response. Please check Gemini API configuration.'}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  // Voice recording & transcription
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = e => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        // Stop all audio tracks
        stream.getTracks().forEach(track => track.stop());

        if (audioBlob.size > 0) {
          setTranscribing(true);
          try {
            const res = await api.transcribeAudio(audioBlob);
            if (res.transcription) {
              setInput(prev => (prev ? `${prev} ${res.transcription}` : res.transcription));
              showToast('Voice transcribed successfully with Gemini!', 'success');
            } else {
              showToast('No speech detected in audio.', 'info');
            }
          } catch (err: any) {
            showToast(err.message || 'Voice transcription failed', 'error');
          } finally {
            setTranscribing(false);
          }
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err: any) {
      console.error('Microphone error:', err);
      showToast('Could not access microphone: ' + err.message, 'error');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleClearHistory = () => {
    setMessages([
      {
        id: 'welcome',
        role: 'model',
        content:
          'Conversation history reset. How can I assist your screening and recruitment evaluation?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Slide-over Panel */}
      <div className="relative w-full max-w-lg bg-white shadow-2xl flex flex-col h-full z-10 border-l border-slate-200">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 to-blue-400 flex items-center justify-center text-white shadow-md shadow-indigo-500/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="text-sm font-bold flex items-center gap-2">
                <span>Gemini Recruiter Copilot</span>
                <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded-sm bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                  AI Multi-Turn
                </span>
              </div>
              <div className="text-[11px] text-slate-400">
                Decision-support recruitment conversational intelligence
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={handleClearHistory}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Reset conversation"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Close panel"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Model & Search Bar Controls */}
        <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
          {/* Model tier toggle */}
          <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200 shadow-2xs">
            <button
              type="button"
              onClick={() => setModelSpeed('fast')}
              className={`px-2 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition-all ${
                modelSpeed === 'fast'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
              title="gemini-3.1-flash-lite (fast response)"
            >
              <Zap className="w-3 h-3" />
              <span>Fast</span>
            </button>
            <button
              type="button"
              onClick={() => setModelSpeed('general')}
              className={`px-2 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition-all ${
                modelSpeed === 'general'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
              title="gemini-3.5-flash (balanced & general tasks)"
            >
              <Sparkles className="w-3 h-3" />
              <span>General</span>
            </button>
            <button
              type="button"
              onClick={() => setModelSpeed('deep')}
              className={`px-2 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition-all ${
                modelSpeed === 'deep'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
              title="gemini-3.1-pro-preview (complex analysis)"
            >
              <Brain className="w-3 h-3" />
              <span>Deep Pro</span>
            </button>
          </div>

          {/* Google Search Grounding toggle */}
          <button
            type="button"
            onClick={() => setUseSearch(!useSearch)}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-semibold border flex items-center gap-1.5 transition-all ${
              useSearch
                ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <Globe className={`w-3.5 h-3.5 ${useSearch ? 'text-emerald-600' : 'text-slate-400'}`} />
            <span>Search Grounding {useSearch ? 'ON' : 'OFF'}</span>
          </button>
        </div>

        {/* Active Context Indicator */}
        {(activeCandidateName || activeJobTitle) && (
          <div className="px-4 py-2 bg-indigo-50/80 border-b border-indigo-100 flex items-center gap-2 text-[11px] text-indigo-900">
            <span className="font-bold uppercase tracking-wider text-[10px] text-indigo-600 shrink-0">
              Active Context:
            </span>
            <div className="truncate">
              {activeCandidateName && (
                <span className="font-semibold">{activeCandidateName}</span>
              )}
              {activeCandidateName && activeJobTitle && <span> • </span>}
              {activeJobTitle && <span>{activeJobTitle}</span>}
            </div>
          </div>
        )}

        {/* Messages Thread (Scrollable) */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/40">
          {messages.map(msg => (
            <div
              key={msg.id}
              className={`flex items-start gap-2.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.role === 'model' && (
                <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-3.5 text-xs leading-relaxed shadow-2xs ${
                  msg.role === 'user'
                    ? 'bg-indigo-600 text-white rounded-tr-none'
                    : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.content}</div>

                {/* Google Search grounding references */}
                {msg.searchSources && msg.searchSources.length > 0 && (
                  <div className="mt-2.5 pt-2 border-t border-slate-100 text-[10px] text-slate-500">
                    <span className="font-semibold block mb-1 flex items-center gap-1 text-emerald-700">
                      <Globe className="w-3 h-3" />
                      Google Search Sources:
                    </span>
                    <div className="space-y-1">
                      {msg.searchSources.map((source, idx) => (
                        <a
                          key={idx}
                          href={source.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 text-indigo-600 hover:underline truncate"
                        >
                          <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                          <span className="truncate">{source.title || source.uri}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                <div
                  className={`text-[9px] mt-1 text-right ${
                    msg.role === 'user' ? 'text-indigo-200' : 'text-slate-400'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>

              {msg.role === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-white rounded-2xl rounded-tl-none p-3.5 border border-slate-200 shadow-2xs text-xs text-slate-500 flex items-center gap-2">
                <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />
                <span>Thinking with Gemini {modelSpeed}...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Pills */}
        <div className="px-4 py-2 border-t border-slate-200 bg-white flex items-center gap-1.5 overflow-x-auto whitespace-nowrap text-xs">
          <button
            type="button"
            onClick={() =>
              handleSend(
                activeCandidateName
                  ? `Generate 5 technical interview questions for ${activeCandidateName} targeting their missing skills.`
                  : 'Draft 5 role-specific interview questions for this job description.'
              )
            }
            className="px-2.5 py-1 rounded-full bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-600 text-[11px] font-medium border border-slate-200 transition-colors shrink-0"
          >
            🎯 Interview Questions
          </button>
          <button
            type="button"
            onClick={() =>
              handleSend(
                activeCandidateName
                  ? `Analyze ${activeCandidateName}'s skills gap and estimate ramp-up time.`
                  : 'Analyze common candidate skill gaps in this pipeline.'
              )
            }
            className="px-2.5 py-1 rounded-full bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-600 text-[11px] font-medium border border-slate-200 transition-colors shrink-0"
          >
            🔍 Skill Gap Analysis
          </button>
          <button
            type="button"
            onClick={() => {
              setUseSearch(true);
              handleSend(
                activeJobTitle
                  ? `Search current market salary ranges and compensation benchmarks for ${activeJobTitle}.`
                  : 'Search competitive market salary rates for software roles.'
              );
            }}
            className="px-2.5 py-1 rounded-full bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-600 text-[11px] font-medium border border-slate-200 transition-colors shrink-0"
          >
            🌐 Search Market Salary
          </button>
        </div>

        {/* Input & Voice Controls */}
        <div className="p-3 bg-white border-t border-slate-200">
          {transcribing && (
            <div className="mb-2 p-2 rounded-lg bg-indigo-50 text-indigo-700 text-xs flex items-center gap-2">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>Transcribing voice with gemini-3.5-transcribe...</span>
            </div>
          )}

          <form
            onSubmit={e => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            {/* Mic button */}
            <button
              type="button"
              onClick={isRecording ? stopRecording : startRecording}
              className={`p-2.5 rounded-xl border transition-colors ${
                isRecording
                  ? 'bg-rose-500 text-white border-rose-600 animate-pulse'
                  : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
              }`}
              title={isRecording ? 'Stop voice recording' : 'Dictate message with microphone'}
            >
              {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            <input
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder={
                isRecording
                  ? 'Listening to microphone...'
                  : 'Ask Copilot about candidates, requirements, or skills...'
              }
              disabled={loading || isRecording}
              className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-indigo-500 focus:bg-white transition-all"
            />

            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white shadow-xs shadow-indigo-600/30 transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

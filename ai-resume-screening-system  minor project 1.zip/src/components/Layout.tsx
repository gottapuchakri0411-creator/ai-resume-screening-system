import React, { useState } from 'react';
import { Outlet, Navigate, useLocation } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { Navbar } from './Navbar';
import { useAuth } from '../context/AuthContext';
import { Loader2, Sparkles } from 'lucide-react';
import { RecruiterCopilotDrawer } from './RecruiterCopilotDrawer';

export const Layout: React.FC = () => {
  const { user, loading } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [copilotOpen, setCopilotOpen] = useState(false);
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center gap-3">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
        <p className="text-sm font-medium text-slate-500">Loading AI Resume Screening System...</p>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Generate dynamic page title based on path
  const getHeaderInfo = () => {
    const path = location.pathname;
    if (path.startsWith('/dashboard')) {
      return { title: 'Recruitment Dashboard', subtitle: 'Overview of jobs, screened candidates, and match analytics' };
    }
    if (path === '/jobs') {
      return { title: 'Job Openings', subtitle: 'Manage job descriptions and resume intake pipelines' };
    }
    if (path === '/jobs/create') {
      return { title: 'Create Job Posting', subtitle: 'Define position requirements, technical skills, and experience criteria' };
    }
    if (path.startsWith('/jobs/')) {
      return { title: 'Job Details & Resumes', subtitle: 'Review job posting, upload resumes, and trigger screening' };
    }
    if (path.startsWith('/screening/')) {
      return { title: 'AI Candidate Screening', subtitle: 'NLP ranking, skill match breakdown, and semantic explanations' };
    }
    if (path === '/candidates') {
      return { title: 'Candidate Talent Pool', subtitle: 'Search, filter, and review ranked candidates across all jobs' };
    }
    if (path.startsWith('/candidates/')) {
      return { title: 'Candidate Evaluation', subtitle: 'Detailed resume analysis, matched skills, and recruiter notes' };
    }
    if (path === '/analytics') {
      return { title: 'Screening Analytics', subtitle: 'Match score distributions, skill demand trends, and candidate stats' };
    }
    if (path === '/audio-studio') {
      return { title: 'AI Audio & Focus Studio', subtitle: 'Speech-to-text dictation (gemini-3.5-transcribe) and Lyria music generation' };
    }
    if (path === '/settings') {
      return { title: 'Settings & Compliance', subtitle: 'Recruiter profile, responsible AI principles, and system preferences' };
    }
    return { title: 'AI Resume Screening System', subtitle: 'Decision-support recruitment platform' };
  };

  const headerInfo = getHeaderInfo();

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar mobileOpen={mobileOpen} onCloseMobile={() => setMobileOpen(false)} />

      <div className="flex-1 flex flex-col lg:pl-64 min-w-0">
        <Navbar
          onToggleMobile={() => setMobileOpen(!mobileOpen)}
          onOpenCopilot={() => setCopilotOpen(true)}
          title={headerInfo.title}
          subtitle={headerInfo.subtitle}
        />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <Outlet />
        </main>
      </div>

      {/* Floating Copilot Launcher Button */}
      <button
        onClick={() => setCopilotOpen(true)}
        className="fixed bottom-6 right-6 z-40 flex items-center gap-2 px-4 py-3 rounded-full bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs shadow-xl shadow-slate-900/30 border border-slate-700 hover:scale-105 active:scale-95 transition-all group"
        title="Open AI Recruiter Copilot (Gemini multi-turn chat & search grounding)"
      >
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
        <Sparkles className="w-4 h-4 text-indigo-400 group-hover:rotate-12 transition-transform" />
        <span>Ask Copilot</span>
      </button>

      {/* Slide-over Multi-Turn Chat Drawer */}
      <RecruiterCopilotDrawer
        isOpen={copilotOpen}
        onClose={() => setCopilotOpen(false)}
      />
    </div>
  );
};

import React from 'react';

export const ScoreBadge: React.FC<{ score: number; size?: 'sm' | 'md' | 'lg'; showLabel?: boolean }> = ({
  score,
  size = 'md',
  showLabel = false
}) => {
  let colorClass = 'bg-rose-50 text-rose-700 border-rose-200';
  let label = 'Low Match';
  let ringClass = 'ring-rose-500/20';

  if (score >= 85) {
    colorClass = 'bg-emerald-50 text-emerald-700 border-emerald-200';
    label = 'Strong Match';
    ringClass = 'ring-emerald-500/20';
  } else if (score >= 70) {
    colorClass = 'bg-blue-50 text-blue-700 border-blue-200';
    label = 'Good Match';
    ringClass = 'ring-blue-500/20';
  } else if (score >= 55) {
    colorClass = 'bg-amber-50 text-amber-700 border-amber-200';
    label = 'Moderate';
    ringClass = 'ring-amber-500/20';
  }

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 font-semibold',
    md: 'text-sm px-2.5 py-1 font-bold',
    lg: 'text-base px-3.5 py-1.5 font-extrabold'
  };

  return (
    <div className="inline-flex items-center gap-1.5">
      <span className={`inline-flex items-center rounded-lg border shadow-xs ring-2 ${ringClass} ${colorClass} ${sizeClasses[size]}`}>
        {score}%
      </span>
      {showLabel && (
        <span className="text-xs font-medium text-slate-500 hidden sm:inline">
          {label}
        </span>
      )}
    </div>
  );
};

export const StatusBadge: React.FC<{ status: 'Shortlisted' | 'Under Review' | 'Reviewed' | 'Rejected' | string }> = ({
  status
}) => {
  const styles: Record<string, string> = {
    Shortlisted: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    'Under Review': 'bg-blue-50 text-blue-700 border-blue-200',
    Reviewed: 'bg-slate-100 text-slate-700 border-slate-200',
    Rejected: 'bg-rose-50 text-rose-700 border-rose-200',
    Active: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    Closed: 'bg-slate-100 text-slate-600 border-slate-200',
    Draft: 'bg-amber-50 text-amber-700 border-amber-200'
  };

  const dotStyles: Record<string, string> = {
    Shortlisted: 'bg-emerald-500',
    'Under Review': 'bg-blue-500',
    Reviewed: 'bg-slate-400',
    Rejected: 'bg-rose-500',
    Active: 'bg-emerald-500',
    Closed: 'bg-slate-400',
    Draft: 'bg-amber-500'
  };

  const currentStyle = styles[status] || 'bg-slate-50 text-slate-700 border-slate-200';
  const dotStyle = dotStyles[status] || 'bg-slate-400';

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold border ${currentStyle}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${dotStyle}`} />
      {status}
    </span>
  );
};

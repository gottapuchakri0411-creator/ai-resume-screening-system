// Standard English stopwords for text tokenization and TF-IDF calculation
const STOPWORDS = new Set([
  'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and', 'any', 'are', 'aren\'t', 'as', 'at',
  'be', 'because', 'been', 'before', 'being', 'below', 'between', 'both', 'but', 'by',
  'can', 'can\'t', 'cannot', 'could', 'couldn\'t', 'did', 'didn\'t', 'do', 'does', 'doesn\'t', 'doing', 'don\'t', 'down', 'during',
  'each', 'few', 'for', 'from', 'further', 'had', 'hadn\'t', 'has', 'hasn\'t', 'have', 'haven\'t', 'having', 'he', 'he\'d', 'he\'ll', 'he\'s',
  'her', 'here', 'here\'s', 'hers', 'herself', 'him', 'himself', 'his', 'how', 'how\'s', 'i', 'i\'d', 'i\'ll', 'i\'m', 'i\'ve', 'if', 'in',
  'into', 'is', 'isn\'t', 'it', 'it\'s', 'its', 'itself', 'let\'s', 'me', 'more', 'most', 'mustn\'t', 'my', 'myself',
  'no', 'nor', 'not', 'of', 'off', 'on', 'once', 'only', 'or', 'other', 'ought', 'our', 'ours', 'ourselves', 'out', 'over', 'own',
  'same', 'shan\'t', 'she', 'she\'d', 'she\'ll', 'she\'s', 'should', 'shouldn\'t', 'so', 'some', 'such',
  'than', 'that', 'that\'s', 'the', 'their', 'theirs', 'them', 'themselves', 'then', 'there', 'there\'s', 'these', 'they', 'they\'d',
  'they\'ll', 'they\'re', 'they\'ve', 'this', 'those', 'through', 'to', 'too', 'under', 'until', 'up', 'very',
  'was', 'wasn\'t', 'we', 'we\'d', 'we\'ll', 'we\'re', 'we\'ve', 'were', 'weren\'t', 'what', 'what\'s', 'when', 'when\'s', 'where', 'where\'s',
  'which', 'while', 'who', 'who\'s', 'whom', 'why', 'why\'s', 'with', 'won\'t', 'would', 'wouldn\'t', 'you', 'you\'d', 'you\'ll', 'you\'re', 'you\'ve', 'your', 'yours', 'yourself', 'yourselves'
]);

// Normalization dictionary for technical and professional skills
export const SKILL_CANONICAL_MAP: Record<string, string> = {
  'js': 'JavaScript',
  'javascript': 'JavaScript',
  'ts': 'TypeScript',
  'typescript': 'TypeScript',
  'react': 'React',
  'reactjs': 'React',
  'react.js': 'React',
  'vue': 'Vue.js',
  'vuejs': 'Vue.js',
  'vue.js': 'Vue.js',
  'angular': 'Angular',
  'angularjs': 'Angular',
  'node': 'Node.js',
  'nodejs': 'Node.js',
  'node.js': 'Node.js',
  'express': 'Express',
  'expressjs': 'Express',
  'express.js': 'Express',
  'python': 'Python',
  'python3': 'Python',
  'py': 'Python',
  'golang': 'Go',
  'go': 'Go',
  'rust': 'Rust',
  'java': 'Java',
  'c++': 'C++',
  'cpp': 'C++',
  'c#': 'C#',
  'csharp': 'C#',
  '.net': '.NET',
  'dotnet': '.NET',
  'k8s': 'Kubernetes',
  'kubernetes': 'Kubernetes',
  'docker': 'Docker',
  'postgres': 'PostgreSQL',
  'postgresql': 'PostgreSQL',
  'psql': 'PostgreSQL',
  'mysql': 'MySQL',
  'mongodb': 'MongoDB',
  'mongo': 'MongoDB',
  'redis': 'Redis',
  'aws': 'AWS',
  'amazon web services': 'AWS',
  'gcp': 'GCP',
  'google cloud': 'GCP',
  'google cloud platform': 'GCP',
  'azure': 'Azure',
  'microsoft azure': 'Azure',
  'ml': 'Machine Learning',
  'machine learning': 'Machine Learning',
  'ai': 'Artificial Intelligence',
  'artificial intelligence': 'Artificial Intelligence',
  'nlp': 'NLP',
  'natural language processing': 'NLP',
  'dl': 'Deep Learning',
  'deep learning': 'Deep Learning',
  'pytorch': 'PyTorch',
  'tensorflow': 'TensorFlow',
  'tf': 'TensorFlow',
  'scikit-learn': 'Scikit-Learn',
  'sklearn': 'Scikit-Learn',
  'ci/cd': 'CI/CD',
  'cicd': 'CI/CD',
  'continuous integration': 'CI/CD',
  'git': 'Git',
  'github': 'GitHub',
  'gitlab': 'GitLab',
  'rest': 'REST API',
  'rest api': 'REST API',
  'restful': 'REST API',
  'restful api': 'REST API',
  'graphql': 'GraphQL',
  'gql': 'GraphQL',
  'tailwind': 'Tailwind CSS',
  'tailwindcss': 'Tailwind CSS',
  'html': 'HTML5',
  'html5': 'HTML5',
  'css': 'CSS3',
  'css3': 'CSS3',
  'sass': 'SASS',
  'scss': 'SASS',
  'nextjs': 'Next.js',
  'next.js': 'Next.js',
  'fastapi': 'FastAPI',
  'flask': 'Flask',
  'django': 'Django',
  'sql': 'SQL',
  'nosql': 'NoSQL'
};

/**
 * Normalizes skill string to canonical casing and standard alias
 */
export function normalizeSkill(skill: string): string {
  const clean = skill.trim().toLowerCase();
  if (SKILL_CANONICAL_MAP[clean]) {
    return SKILL_CANONICAL_MAP[clean];
  }
  // Title case for general skills
  return skill.trim().replace(/\w\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substring(1));
}

/**
 * Tokenizes text into lowercase terms, removing punctuation (preserving +, #, .)
 */
export function tokenize(text: string): string[] {
  if (!text) return [];
  const words = text
    .toLowerCase()
    .replace(/[^\w\s+#.-]/g, ' ')
    .split(/\s+/);

  return words.filter(w => w.length > 1 && !STOPWORDS.has(w));
}

/**
 * Calculates Term Frequency (TF) vector for a document
 */
export function computeTF(tokens: string[]): Map<string, number> {
  const tf = new Map<string, number>();
  const total = tokens.length || 1;
  for (const token of tokens) {
    tf.set(token, (tf.get(token) || 0) + 1);
  }
  for (const [key, count] of tf.entries()) {
    tf.set(key, count / total);
  }
  return tf;
}

/**
 * Computes Cosine Similarity between Job Description text and Resume text
 */
export function computeCosineSimilarity(textA: string, textB: string): number {
  const tokensA = tokenize(textA);
  const tokensB = tokenize(textB);

  if (tokensA.length === 0 || tokensB.length === 0) return 0;

  const tfA = computeTF(tokensA);
  const tfB = computeTF(tokensB);

  const allKeys = new Set([...tfA.keys(), ...tfB.keys()]);
  let dotProduct = 0;
  let magA = 0;
  let magB = 0;

  for (const key of allKeys) {
    const valA = tfA.get(key) || 0;
    const valB = tfB.get(key) || 0;
    dotProduct += valA * valB;
    magA += valA * valA;
    magB += valB * valB;
  }

  magA = Math.sqrt(magA);
  magB = Math.sqrt(magB);

  if (magA === 0 || magB === 0) return 0;
  return Math.min(1, Math.max(0, dotProduct / (magA * magB)));
}

/**
 * Extracts candidate basic contact info using deterministic regex and heuristic NLP
 */
export function extractBasicContactInfo(text: string, originalFilename: string) {
  // Candidate Name extraction heuristic:
  // Usually in first 3 lines of resume
  const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0);
  let candidateName = '';

  for (let i = 0; i < Math.min(5, lines.length); i++) {
    const line = lines[i];
    // Exclude header words, emails, phone numbers, urls
    if (
      !line.includes('@') &&
      !line.includes('http') &&
      !line.match(/\d{3}/) &&
      !line.toLowerCase().includes('resume') &&
      !line.toLowerCase().includes('curriculum vitae') &&
      !line.toLowerCase().includes('page ') &&
      line.length >= 3 &&
      line.length <= 40
    ) {
      candidateName = line.replace(/[^A-Za-z\s.'-]/g, '').trim();
      if (candidateName.split(/\s+/).length >= 2) {
        break;
      }
    }
  }

  // Fallback to filename if not found
  if (!candidateName || candidateName.length < 3) {
    const base = originalFilename.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' ');
    candidateName = base.replace(/resume|cv/gi, '').trim() || 'Candidate';
  }

  // Email regex
  const emailMatch = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
  const email = emailMatch ? emailMatch[0].toLowerCase() : undefined;

  // Phone regex
  const phoneMatch = text.match(/(?:\+?\d{1,3}[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)\d{3}[-.\s]?\d{4}/);
  const phone = phoneMatch ? phoneMatch[0].trim() : undefined;

  // Education degree heuristic
  let education = '';
  const eduMatch = text.match(/(?:bachelor(?:'s)?|master(?:'s)?|ph\.?d|b\.s\.|m\.s\.|b\.tech|b\.e\.|associate(?:'s)?)[^\n\r.,;]{2,60}/i);
  if (eduMatch) {
    education = eduMatch[0].trim();
  }

  // Years of experience heuristic
  let experienceYears = 0;
  const expMatch = text.match(/(\d+)\+?\s*(?:years?|yrs?)(?:\s+of)?(?:\s+(?:professional|relevant|hands-on|industry))?\s+experience/i);
  if (expMatch) {
    experienceYears = parseInt(expMatch[1], 10);
  } else {
    // Count year ranges like 2018 - 2022
    const years = text.match(/\b(19\d\d|20\d\d)\b/g);
    if (years && years.length >= 2) {
      const numYears = years.map(y => parseInt(y, 10)).filter(y => y <= new Date().getFullYear());
      if (numYears.length >= 2) {
        const minYear = Math.min(...numYears);
        const maxYear = Math.max(...numYears);
        const diff = maxYear - minYear;
        if (diff > 0 && diff < 30) {
          experienceYears = Math.min(diff, 15);
        }
      }
    }
  }

  return {
    candidateName,
    email,
    phone,
    education,
    experienceYears
  };
}

/**
 * Extracts recognized skills from resume text by cross-referencing skill dictionary and word patterns
 */
export function extractSkillsFromText(text: string): string[] {
  const foundSkills = new Set<string>();
  const lowerText = ` ${text.toLowerCase()} `;

  // Check known canonical dictionary
  for (const [key, canonical] of Object.entries(SKILL_CANONICAL_MAP)) {
    // Regex boundary matching
    const escaped = key.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&');
    const regex = new RegExp(`(^|[^a-zA-Z0-9+#.-])${escaped}([^a-zA-Z0-9+#.-]|$)`, 'i');
    if (regex.test(lowerText)) {
      foundSkills.add(canonical);
    }
  }

  return Array.from(foundSkills);
}

/**
 * Matches candidate's extracted skills against job required and preferred skills
 */
export function matchSkills(
  resumeText: string,
  requiredSkills: string[],
  preferredSkills: string[]
) {
  const resumeSkills = extractSkillsFromText(resumeText);
  const resumeSkillsSet = new Set(resumeSkills.map(s => s.toLowerCase()));

  // Also check direct occurrences of skill name in text
  const checkHasSkill = (skill: string) => {
    const norm = normalizeSkill(skill).toLowerCase();
    if (resumeSkillsSet.has(norm)) return true;
    const escaped = skill.toLowerCase().replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&');
    const regex = new RegExp(`(^|[^a-zA-Z0-9+#.-])${escaped}([^a-zA-Z0-9+#.-]|$)`, 'i');
    return regex.test(resumeText.toLowerCase());
  };

  const matchedRequired: string[] = [];
  const missingRequired: string[] = [];
  const matchedPreferred: string[] = [];

  for (const skill of requiredSkills) {
    if (checkHasSkill(skill)) {
      matchedRequired.push(normalizeSkill(skill));
    } else {
      missingRequired.push(normalizeSkill(skill));
    }
  }

  for (const skill of preferredSkills) {
    if (checkHasSkill(skill)) {
      matchedPreferred.push(normalizeSkill(skill));
    }
  }

  const allMatched = Array.from(new Set([...matchedRequired, ...matchedPreferred]));
  const allMissing = missingRequired;

  // Calculate skill match percentage (weighted: required 80%, preferred 20%)
  const reqTotal = requiredSkills.length || 1;
  const reqScore = (matchedRequired.length / reqTotal) * 80;

  const prefTotal = preferredSkills.length || 1;
  const prefScore = preferredSkills.length > 0 ? (matchedPreferred.length / prefTotal) * 20 : 20;

  const skillScore = Math.min(100, Math.round(reqScore + prefScore));

  return {
    matchedSkills: allMatched,
    missingSkills: allMissing,
    skillScore,
    resumeSkills
  };
}

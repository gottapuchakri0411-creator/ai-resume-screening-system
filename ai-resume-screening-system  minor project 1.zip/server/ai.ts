import { GoogleGenAI, Type } from '@google/genai';

let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

export interface AIScreeningResult {
  candidateName: string;
  email?: string;
  phone?: string;
  extractedSkills: string[];
  experienceYears: number;
  educationSummary: string;
  matchedSkills: string[];
  missingSkills: string[];
  relevantExperience: string;
  educationRelevance: string;
  satisfiedRequirements: string[];
  missingRequirements: string[];
  explanation: string;
  semanticScore: number; // 0 - 100
  recommendedStatus: 'Shortlisted' | 'Under Review' | 'Reviewed' | 'Rejected';
}

export async function analyzeResumeWithGemini(
  jobTitle: string,
  jobDescription: string,
  requiredSkills: string[],
  preferredSkills: string[],
  minimumExperience: number,
  educationRequirements: string,
  resumeText: string,
  originalFilename: string
): Promise<AIScreeningResult> {
  const ai = getAiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is not configured on the server. Please ensure GEMINI_API_KEY is set in environment secrets.');
  }

  const systemInstruction = `
You are an expert, objective AI Recruitment and Resume Screening Specialist.
Your purpose is to assist human recruiters by screening resume text against an exact job description.
The human recruiter is always the final decision-maker.

CRITICAL RESPONSIBLE AI DIRECTIVES:
1. STRICT IMPARTIALITY: Evaluate ONLY on job-relevant skills, professional experience, education, projects, certifications, and technical proficiencies.
2. ABSOLUTELY FORBIDDEN: Do NOT evaluate or score candidates based on gender, name, age, race, ethnicity, religion, caste, nationality, disability, marital status, sexual orientation, political views, or any protected personal characteristics.
3. GROUNDING & HONESTY: Never invent, hallucinate, or extrapolate qualifications that are not explicitly evidenced in the provided resume text. If a skill or experience is missing, record it honestly.
4. EXPLANATION: Provide clear, transparent, actionable explanations so the recruiter understands why requirements were satisfied or unmet.
`;

  const prompt = `
JOB INFORMATION:
Job Title: ${jobTitle}
Minimum Experience: ${minimumExperience} years
Education Requirements: ${educationRequirements}
Required Skills: ${requiredSkills.join(', ')}
Preferred Skills: ${preferredSkills.join(', ')}
Job Description:
${jobDescription}

---------------------------------------------------------
CANDIDATE RESUME TEXT (Source File: ${originalFilename}):
${resumeText}

---------------------------------------------------------
TASK:
Analyze this resume strictly against the job requirements.
1. Extract candidate name, email, phone number, education, and years of experience as found in the resume.
2. Extract all skills found in the resume.
3. Identify which required/preferred skills are matched and which are missing.
4. Analyze how well their experience meets the ${minimumExperience} years requirement and job duties.
5. Analyze how well their education meets the education requirements.
6. List specific requirements satisfied and requirements not found.
7. Provide a concise, professional explanation for the recruiter.
8. Calculate a semantic match score between 0 and 100 based strictly on evidence.
9. Recommend a status: "Shortlisted" (strong match >= 80), "Under Review" (medium match 60-79), "Reviewed" (low match 45-59), or "Rejected" (<45).
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.2, // Low temperature for high objectivity and consistency
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            candidateName: { type: Type.STRING },
            email: { type: Type.STRING },
            phone: { type: Type.STRING },
            extractedSkills: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            experienceYears: { type: Type.NUMBER },
            educationSummary: { type: Type.STRING },
            matchedSkills: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            missingSkills: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            relevantExperience: { type: Type.STRING },
            educationRelevance: { type: Type.STRING },
            satisfiedRequirements: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            missingRequirements: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            explanation: { type: Type.STRING },
            semanticScore: { type: Type.NUMBER },
            recommendedStatus: {
              type: Type.STRING,
              enum: ['Shortlisted', 'Under Review', 'Reviewed', 'Rejected']
            }
          },
          required: [
            'candidateName',
            'extractedSkills',
            'matchedSkills',
            'missingSkills',
            'relevantExperience',
            'educationRelevance',
            'satisfiedRequirements',
            'missingRequirements',
            'explanation',
            'semanticScore',
            'recommendedStatus'
          ]
        }
      }
    });

    const raw = response.text;
    if (!raw) {
      throw new Error('Gemini API returned an empty response.');
    }

    const data = JSON.parse(raw);
    return {
      candidateName: data.candidateName || originalFilename.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' '),
      email: data.email || undefined,
      phone: data.phone || undefined,
      extractedSkills: Array.isArray(data.extractedSkills) ? data.extractedSkills : [],
      experienceYears: typeof data.experienceYears === 'number' ? data.experienceYears : 0,
      educationSummary: data.educationSummary || 'Not specified in resume',
      matchedSkills: Array.isArray(data.matchedSkills) ? data.matchedSkills : [],
      missingSkills: Array.isArray(data.missingSkills) ? data.missingSkills : [],
      relevantExperience: data.relevantExperience || 'Relevant experience analyzed from resume.',
      educationRelevance: data.educationRelevance || 'Education analyzed against job requirement.',
      satisfiedRequirements: Array.isArray(data.satisfiedRequirements) ? data.satisfiedRequirements : [],
      missingRequirements: Array.isArray(data.missingRequirements) ? data.missingRequirements : [],
      explanation: data.explanation || 'Screening evaluated against the job description.',
      semanticScore: Math.min(100, Math.max(0, Math.round(data.semanticScore || 50))),
      recommendedStatus: ['Shortlisted', 'Under Review', 'Reviewed', 'Rejected'].includes(data.recommendedStatus)
        ? data.recommendedStatus
        : 'Under Review'
    };
  } catch (err: any) {
    console.error('Gemini API screening error:', err);
    throw new Error(`AI Semantic Analysis failed: ${err.message || 'Model execution error'}`);
  }
}

export interface CopilotChatMessage {
  role: 'user' | 'model';
  content: string;
}

export interface CopilotChatContext {
  jobTitle?: string;
  jobDescription?: string;
  requiredSkills?: string[];
  preferredSkills?: string[];
  candidateName?: string;
  candidateExperience?: number;
  resumeText?: string;
  matchScore?: number;
  matchedSkills?: string[];
  missingSkills?: string[];
  explanation?: string;
}

export async function generateCopilotChatResponse(
  messages: CopilotChatMessage[],
  context?: CopilotChatContext,
  options?: {
    useSearch?: boolean;
    modelSpeed?: 'fast' | 'general' | 'deep';
  }
): Promise<{ reply: string; searchSources?: { title?: string; uri?: string }[] }> {
  const ai = getAiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is not configured on the server. Please check environment configuration.');
  }

  // Model selection per guidelines:
  // - gemini-3.1-flash-lite for tasks that should happen fast
  // - gemini-3.5-flash for general tasks & Search Grounding
  // - gemini-3.1-pro-preview for particularly complex tasks
  let modelName = 'gemini-3.5-flash';
  if (options?.modelSpeed === 'fast') {
    modelName = 'gemini-3.1-flash-lite';
  } else if (options?.modelSpeed === 'deep') {
    modelName = 'gemini-3.1-pro-preview';
  }

  let systemInstruction = `You are the AI Recruitment Copilot & Screening Advisor within the AI Resume Screening System.
Your job is to assist human recruiters in evaluating candidates, crafting interview questions, comparing applicants, assessing technical skill gaps, and optimizing job descriptions.

RESPONSIBLE AI RULES:
- Never score or evaluate candidates based on protected demographic attributes (gender, age, race, religion, disability, etc.).
- Maintain strict objectivity and honesty. Do not invent candidate accomplishments.
- Always provide clear, actionable, professional recruitment advice.
- When answering about a specific candidate or job posting, ground your reasoning strictly in the provided candidate resume and job criteria.`;

  if (context) {
    let contextDetails = '\n\nCURRENT RECRUITMENT CONTEXT:';
    if (context.jobTitle) {
      contextDetails += `\n- Job Title: ${context.jobTitle}`;
    }
    if (context.requiredSkills && context.requiredSkills.length > 0) {
      contextDetails += `\n- Required Skills: ${context.requiredSkills.join(', ')}`;
    }
    if (context.preferredSkills && context.preferredSkills.length > 0) {
      contextDetails += `\n- Preferred Skills: ${context.preferredSkills.join(', ')}`;
    }
    if (context.jobDescription) {
      contextDetails += `\n- Job Description Summary: ${context.jobDescription.slice(0, 1500)}`;
    }
    if (context.candidateName) {
      contextDetails += `\n- Selected Candidate: ${context.candidateName}`;
      if (context.matchScore !== undefined) {
        contextDetails += ` (Match Score: ${context.matchScore}%)`;
      }
      if (context.matchedSkills && context.matchedSkills.length > 0) {
        contextDetails += `\n- Matched Skills: ${context.matchedSkills.join(', ')}`;
      }
      if (context.missingSkills && context.missingSkills.length > 0) {
        contextDetails += `\n- Missing Skills: ${context.missingSkills.join(', ')}`;
      }
      if (context.explanation) {
        contextDetails += `\n- Screening Explanation: ${context.explanation}`;
      }
      if (context.resumeText) {
        contextDetails += `\n- Resume Snippet: ${context.resumeText.slice(0, 2000)}`;
      }
    }
    systemInstruction += contextDetails;
  }

  // Format messages into GoogleGenAI contents array
  const contents = messages.map(m => ({
    role: m.role,
    parts: [{ text: m.content }]
  }));

  const config: any = {
    systemInstruction,
    temperature: 0.4,
  };

  // Enable Google Search Grounding if requested
  if (options?.useSearch) {
    config.tools = [{ googleSearch: {} }];
    // Ensure we use gemini-3.5-flash for Search Grounding
    modelName = 'gemini-3.5-flash';
  }

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents,
      config,
    });

    const reply = response.text || 'I analyzed the information, but no response text was generated.';

    // Extract search grounding sources if present
    const searchSources: { title?: string; uri?: string }[] = [];
    const groundingChunks = (response.candidates?.[0] as any)?.groundingMetadata?.groundingChunks;
    if (Array.isArray(groundingChunks)) {
      groundingChunks.forEach(chunk => {
        if (chunk.web?.uri) {
          searchSources.push({
            title: chunk.web.title || chunk.web.uri,
            uri: chunk.web.uri,
          });
        }
      });
    }

    return {
      reply,
      searchSources: searchSources.length > 0 ? searchSources : undefined,
    };
  } catch (err: any) {
    console.error('Gemini Copilot chat error:', err);
    throw new Error(`AI Copilot error: ${err.message || 'Failed to generate chat response'}`);
  }
}

export async function transcribeAudioWithGemini(
  audioBase64: string,
  mimeType: string = 'audio/webm'
): Promise<string> {
  const ai = getAiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is not configured on the server.');
  }

  try {
    // Primary: try gemini-3.5-transcribe
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-transcribe',
      contents: [
        {
          inlineData: {
            mimeType,
            data: audioBase64,
          },
        },
        {
          text: 'Transcribe this spoken recruitment note or interview feedback verbatim into clean English text. Do not add conversational commentary, just the accurate transcription.',
        },
      ],
    });

    return response.text?.trim() || '';
  } catch (primaryErr: any) {
    console.warn('gemini-3.5-transcribe failed, falling back to gemini-3.5-flash:', primaryErr.message);
    try {
      const fallbackResponse = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: [
          {
            inlineData: {
              mimeType,
              data: audioBase64,
            },
          },
          {
            text: 'Transcribe this spoken audio verbatim into clean text.',
          },
        ],
      });
      return fallbackResponse.text?.trim() || '';
    } catch (fallbackErr: any) {
      console.error('Audio transcription error:', fallbackErr);
      throw new Error(`Audio transcription failed: ${fallbackErr.message}`);
    }
  }
}

export async function generateMusicWithLyria(
  prompt: string,
  trackType: 'clip' | 'pro' = 'clip'
): Promise<{ audioBase64: string; mimeType: string; lyrics?: string; modelUsed: string }> {
  const ai = getAiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is not configured on the server.');
  }

  const model = trackType === 'pro' ? 'lyria-3-pro-preview' : 'lyria-3-clip-preview';

  try {
    const response = await ai.models.generateContentStream({
      model,
      contents: prompt,
    });

    let audioBase64 = '';
    let lyrics = '';
    let mimeType = 'audio/wav';

    for await (const chunk of response) {
      const parts = chunk.candidates?.[0]?.content?.parts;
      if (!parts) continue;

      for (const part of parts) {
        if (part.inlineData?.data) {
          if (!audioBase64 && part.inlineData.mimeType) {
            mimeType = part.inlineData.mimeType;
          }
          audioBase64 += part.inlineData.data;
        }
        if (part.text && !lyrics) {
          lyrics = part.text;
        }
      }
    }

    if (!audioBase64) {
      throw new Error(`The Lyria model (${model}) did not return any audio data.`);
    }

    return {
      audioBase64,
      mimeType,
      lyrics: lyrics ? lyrics.trim() : undefined,
      modelUsed: model,
    };
  } catch (err: any) {
    console.error('Lyria music generation error:', err);
    throw new Error(`Music generation with ${model} failed: ${err.message || 'Model execution error'}`);
  }
}


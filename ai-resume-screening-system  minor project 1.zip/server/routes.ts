import express, { Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { db } from './db.js';
import {
  authenticateToken,
  AuthenticatedRequest,
  generateToken,
  hashPassword,
  comparePassword
} from './auth.js';
import { extractResumeText } from './parsers.js';
import { processAndScreenResume } from './screeningService.js';
import { Job, Resume, Candidate } from './types.js';
import { generateCopilotChatResponse, transcribeAudioWithGemini, generateMusicWithLyria } from './ai.js';

const router = express.Router();

// Configure multer for memory storage
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext === '.pdf' || ext === '.docx' || ext === '.doc' || ext === '.txt') {
      cb(null, true);
    } else {
      cb(new Error('Unsupported file format. Please upload PDF or DOCX resumes.'));
    }
  }
});

// ==========================================
// 1. AUTHENTICATION ROUTES
// ==========================================

router.post('/auth/register', (req: Request, res: Response) => {
  try {
    const { name, email, password, company, role } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }

    const existing = db.findUserByEmail(email);
    if (existing) {
      return res.status(400).json({ error: 'An account with this email address already exists.' });
    }

    const newUser = db.createUser({
      id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      passwordHash: hashPassword(password),
      company: (company || 'Talent Acquisition').trim(),
      role: (role || 'Recruiter').trim(),
      createdAt: new Date().toISOString()
    });

    const token = generateToken(newUser);
    const { passwordHash: _, ...safeUser } = newUser;

    return res.status(201).json({
      message: 'Account created successfully',
      token,
      user: safeUser
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Registration failed' });
  }
});

router.post('/auth/login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const user = db.findUserByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password credentials.' });
    }

    const isMatch = comparePassword(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid email or password credentials.' });
    }

    const token = generateToken(user);
    const { passwordHash: _, ...safeUser } = user;

    return res.json({
      message: 'Login successful',
      token,
      user: safeUser
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Login failed' });
  }
});

router.get('/auth/me', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  const { passwordHash: _, ...safeUser } = req.user;
  return res.json({ user: safeUser });
});

router.post('/auth/logout', (_req: Request, res: Response) => {
  return res.json({ message: 'Logged out successfully' });
});

// ==========================================
// 2. JOB MANAGEMENT ROUTES
// ==========================================

router.get('/jobs', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const jobs = db.getJobs(req.user?.id);
    return res.json({ jobs });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.post('/jobs', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      title,
      company,
      department,
      location,
      employmentType,
      description,
      requiredSkills,
      preferredSkills,
      minimumExperience,
      educationRequirements,
      status
    } = req.body;

    if (!title || !description) {
      return res.status(400).json({ error: 'Job title and description are required.' });
    }

    const newJob: Job = {
      id: `job_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      recruiterId: req.user!.id,
      title: title.trim(),
      company: (company || req.user!.company || 'Apex Tech Solutions').trim(),
      department: (department || 'General').trim(),
      location: (location || 'Remote').trim(),
      employmentType: employmentType || 'Full-time',
      description: description.trim(),
      requiredSkills: Array.isArray(requiredSkills) ? requiredSkills : [],
      preferredSkills: Array.isArray(preferredSkills) ? preferredSkills : [],
      minimumExperience: Number(minimumExperience) || 0,
      educationRequirements: (educationRequirements || 'Bachelor\'s degree or equivalent').trim(),
      status: status || 'Active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const created = db.createJob(newJob);
    return res.status(201).json({ job: created });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.get('/jobs/:id', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const job = db.getJobById(req.params.id);
    if (!job) {
      return res.status(404).json({ error: 'Job not found.' });
    }

    const resumes = db.getResumesByJob(job.id);
    const screeningResults = db.getScreeningResultsByJob(job.id);

    return res.json({
      job,
      resumes,
      screeningResults
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.put('/jobs/:id', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const existing = db.getJobById(req.params.id);
    if (!existing) {
      return res.status(404).json({ error: 'Job not found.' });
    }

    const updated = db.updateJob(req.params.id, req.body);
    return res.json({ job: updated });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.delete('/jobs/:id', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const success = db.deleteJob(req.params.id);
    if (!success) {
      return res.status(404).json({ error: 'Job not found or already deleted.' });
    }
    return res.json({ message: 'Job and associated candidate screening data deleted.' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 3. RESUME UPLOAD & EXTRACTION ROUTES
// ==========================================

router.post(
  '/jobs/:id/resumes',
  authenticateToken,
  upload.array('resumes', 15),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      const job = db.getJobById(req.params.id);
      if (!job) {
        return res.status(404).json({ error: 'Target job posting was not found.' });
      }

      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) {
        return res.status(400).json({ error: 'No resume files were uploaded.' });
      }

      const uploadResults: Resume[] = [];
      const errors: { filename: string; error: string }[] = [];

      for (const file of files) {
        const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
        const resumeId = `res_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const candidateId = `cand_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

        try {
          // Perform actual text extraction from PDF or DOCX
          const extracted = await extractResumeText(file.buffer, ext, file.originalname);

          // Save extracted resume
          const resume: Resume = {
            id: resumeId,
            candidateId,
            jobId: job.id,
            filename: file.originalname,
            originalName: file.originalname,
            fileType: (ext === 'pdf' ? 'pdf' : ext === 'docx' ? 'docx' : 'txt'),
            fileSize: file.size,
            extractedText: extracted.text,
            processingStatus: 'Uploaded',
            uploadedAt: new Date().toISOString()
          };

          const saved = db.createResume(resume);
          uploadResults.push(saved);
        } catch (extractError: any) {
          errors.push({
            filename: file.originalname,
            error: extractError.message || 'Unable to extract readable text from this resume.'
          });

          // Still save failed resume record for transparent audit tracking
          const failedResume: Resume = {
            id: resumeId,
            candidateId,
            jobId: job.id,
            filename: file.originalname,
            originalName: file.originalname,
            fileType: (ext === 'pdf' ? 'pdf' : 'docx'),
            fileSize: file.size,
            extractedText: '',
            processingStatus: 'Failed',
            failureReason: extractError.message || 'Unable to extract readable text from this resume.',
            uploadedAt: new Date().toISOString()
          };
          db.createResume(failedResume);
        }
      }

      return res.status(201).json({
        message: `Successfully uploaded and extracted ${uploadResults.length} resume(s).`,
        resumes: uploadResults,
        errors: errors.length > 0 ? errors : undefined
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message || 'Resume upload failed' });
    }
  }
);

router.get('/jobs/:id/resumes', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const resumes = db.getResumesByJob(req.params.id);
    return res.json({ resumes });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.delete('/resumes/:id', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const success = db.deleteResume(req.params.id);
    if (!success) {
      return res.status(404).json({ error: 'Resume not found.' });
    }
    return res.json({ message: 'Resume and screening result removed.' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 4. SCREENING & MATCHING ROUTES
// ==========================================

router.post('/screen/:jobId', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const job = db.getJobById(req.params.jobId);
    if (!job) {
      return res.status(404).json({ error: 'Job not found.' });
    }

    const resumes = db.getResumesByJob(job.id);
    if (resumes.length === 0) {
      return res.status(400).json({ error: 'No resumes have been uploaded for this job yet.' });
    }

    const { resumeIds } = req.body;
    const targetResumes = resumeIds && Array.isArray(resumeIds)
      ? resumes.filter(r => resumeIds.includes(r.id))
      : resumes.filter(r => r.processingStatus !== 'Failed');

    if (targetResumes.length === 0) {
      return res.status(400).json({ error: 'No valid resumes available for screening.' });
    }

    const results = [];
    const failures = [];

    for (const resume of targetResumes) {
      try {
        db.updateResume(resume.id, { processingStatus: 'Processing' });
        const screeningResult = await processAndScreenResume(job, resume);
        results.push(screeningResult);
      } catch (err: any) {
        db.updateResume(resume.id, {
          processingStatus: 'Failed',
          failureReason: err.message
        });
        failures.push({ resumeId: resume.id, error: err.message });
      }
    }

    return res.json({
      message: `Screening completed for ${results.length} candidate(s).`,
      results,
      failures: failures.length > 0 ? failures : undefined
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Screening pipeline failed' });
  }
});

router.get('/screen/:jobId', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const job = db.getJobById(req.params.jobId);
    if (!job) {
      return res.status(404).json({ error: 'Job not found.' });
    }

    const screeningResults = db.getScreeningResultsByJob(job.id);
    const candidates = db.getCandidates(req.user?.id);
    const resumes = db.getResumesByJob(job.id);

    // Combine into ranked candidate table records
    const rankedCandidates = screeningResults.map(s => {
      const candidate = candidates.find(c => c.id === s.candidateId);
      const resume = resumes.find(r => r.id === s.resumeId);

      return {
        ...s,
        candidateName: candidate?.name || 'Unknown Candidate',
        candidateEmail: candidate?.email,
        candidatePhone: candidate?.phone,
        experienceYears: candidate?.experienceYears,
        resumeFilename: resume?.originalName || resume?.filename || 'Resume.pdf',
        resumeText: resume?.extractedText || ''
      };
    }).sort((a, b) => b.matchScore - a.matchScore);

    return res.json({
      job,
      rankedCandidates
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.put('/screen/:id/status', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { status } = req.body;
    if (!status || !['Shortlisted', 'Under Review', 'Reviewed', 'Rejected'].includes(status)) {
      return res.status(400).json({ error: 'Invalid candidate status.' });
    }

    const updated = db.updateScreeningResultStatus(req.params.id, status);
    if (!updated) {
      return res.status(404).json({ error: 'Screening result not found.' });
    }

    return res.json({ screeningResult: updated });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 5. CANDIDATE DETAILS & NOTES ROUTES
// ==========================================

router.get('/candidates', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const candidates = db.getCandidates(req.user?.id);
    const jobs = db.getJobs(req.user?.id);

    // Attach latest screening info
    const enriched = candidates.map(c => {
      const screening = db.getScreeningResultByCandidate(c.id);
      const job = screening ? jobs.find(j => j.id === screening.jobId) : undefined;
      return {
        ...c,
        screening,
        jobTitle: job?.title,
        jobId: job?.id
      };
    });

    return res.json({ candidates: enriched });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.get('/candidates/:id', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const candidate = db.getCandidateById(req.params.id);
    if (!candidate) {
      return res.status(404).json({ error: 'Candidate not found.' });
    }

    const screening = db.getScreeningResultByCandidate(candidate.id);
    const job = screening ? db.getJobById(screening.jobId) : undefined;
    const resume = screening ? db.getResumeById(screening.resumeId) : undefined;
    const notes = db.getNotesByCandidate(candidate.id);

    return res.json({
      candidate,
      screening,
      job,
      resume,
      notes
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.post('/candidates/:id/notes', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { content, jobId } = req.body;
    if (!content || !content.trim()) {
      return res.status(400).json({ error: 'Note content cannot be empty.' });
    }

    const candidate = db.getCandidateById(req.params.id);
    if (!candidate) {
      return res.status(404).json({ error: 'Candidate not found.' });
    }

    const newNote = db.createNote({
      id: `note_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      candidateId: candidate.id,
      jobId,
      recruiterId: req.user!.id,
      recruiterName: req.user!.name,
      content: content.trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    return res.status(201).json({ note: newNote });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.put('/notes/:id', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { content } = req.body;
    if (!content || !content.trim()) {
      return res.status(400).json({ error: 'Note content cannot be empty.' });
    }

    const updated = db.updateNote(req.params.id, content.trim());
    if (!updated) {
      return res.status(404).json({ error: 'Note not found.' });
    }

    return res.json({ note: updated });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.delete('/notes/:id', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const deleted = db.deleteNote(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: 'Note not found.' });
    }
    return res.json({ message: 'Note deleted.' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 6. ANALYTICS ROUTES
// ==========================================

router.get('/analytics', authenticateToken, (req: AuthenticatedRequest, res: Response) => {
  try {
    const analytics = db.getAnalytics(req.user?.id);
    return res.json({ analytics });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 7. GEMINI RECRUITER COPILOT & TRANSCRIPTION
// ==========================================

router.post('/copilot/chat', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { messages, candidateId, jobId, useSearch, modelSpeed } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required.' });
    }

    // Context hydration
    let context: any = undefined;
    if (jobId || candidateId) {
      context = {};
      if (jobId) {
        const job = db.getJobById(jobId);
        if (job) {
          context.jobTitle = job.title;
          context.jobDescription = job.description;
          context.requiredSkills = job.requiredSkills;
          context.preferredSkills = job.preferredSkills;
        }
      }
      if (candidateId) {
        const candidate = db.getCandidateById(candidateId);
        if (candidate) {
          context.candidateName = candidate.name;
          context.candidateExperience = candidate.experienceYears;
          const screening = db.getScreeningResultByCandidate(candidateId);
          if (screening) {
            context.matchScore = screening.matchScore;
            context.matchedSkills = screening.matchedSkills;
            context.missingSkills = screening.missingSkills;
            context.explanation = screening.explanation;
            const resume = db.getResumeById(screening.resumeId);
            if (resume) {
              context.resumeText = resume.extractedText;
            }
          }
        }
      }
    }

    const copilotResult = await generateCopilotChatResponse(messages, context, {
      useSearch: !!useSearch,
      modelSpeed: modelSpeed || 'general',
    });

    return res.json(copilotResult);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Copilot generation failed' });
  }
});

router.post(
  '/copilot/transcribe',
  authenticateToken,
  upload.single('audio'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      let audioBase64 = '';
      let mimeType = 'audio/webm';

      if (req.file) {
        audioBase64 = req.file.buffer.toString('base64');
        mimeType = req.file.mimetype || 'audio/webm';
      } else if (req.body.audioBase64) {
        audioBase64 = req.body.audioBase64;
        mimeType = req.body.mimeType || 'audio/webm';
      } else {
        return res.status(400).json({ error: 'Audio file or audioBase64 string required.' });
      }

      const transcription = await transcribeAudioWithGemini(audioBase64, mimeType);
      return res.json({ transcription });
    } catch (err: any) {
      return res.status(500).json({ error: err.message || 'Audio transcription failed' });
    }
  }
);

// ==========================================
// 8. LYRIA MUSIC GENERATION
// ==========================================

router.post('/music/generate', authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { prompt, trackType } = req.body;

    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({ error: 'A prompt describing the music track is required.' });
    }

    const type = trackType === 'pro' ? 'pro' : 'clip';
    const result = await generateMusicWithLyria(prompt.trim(), type);

    return res.json({
      success: true,
      audioBase64: result.audioBase64,
      mimeType: result.mimeType,
      lyrics: result.lyrics,
      modelUsed: result.modelUsed,
      trackType: type,
      prompt: prompt.trim(),
      generatedAt: new Date().toISOString()
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Music generation failed' });
  }
});

export default router;

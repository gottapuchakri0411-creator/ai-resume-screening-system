import mammoth from 'mammoth';

// Dynamic import or safe handler for pdf-parse to guarantee ESM compatibility
let pdfParseFn: any = null;

async function getPdfParser() {
  if (!pdfParseFn) {
    try {
      const module = await import('pdf-parse');
      pdfParseFn = (module as any).default || module;
    } catch (err) {
      console.error('Failed to import pdf-parse dynamically:', err);
      throw new Error('PDF parsing library is unavailable');
    }
  }
  return pdfParseFn;
}

export interface ExtractedDocument {
  text: string;
  pageCount?: number;
  wordCount: number;
}

/**
 * Extracts raw readable text from PDF and DOCX buffers.
 * Cleans control characters, standardizes line breaks, and returns structured extraction metadata.
 */
export async function extractResumeText(
  buffer: Buffer,
  fileType: 'pdf' | 'docx' | 'txt' | string,
  originalFilename: string
): Promise<ExtractedDocument> {
  const normalizedType = fileType.toLowerCase().replace('.', '');

  if (normalizedType === 'pdf') {
    try {
      const parser = await getPdfParser();
      const pdfData = await parser(buffer);
      const rawText = pdfData.text || '';
      const cleaned = cleanExtractedText(rawText);

      if (!cleaned || cleaned.trim().length < 20) {
        throw new Error('Extracted PDF text is too short or empty. The file may be image-only/scanned without OCR.');
      }

      return {
        text: cleaned,
        pageCount: pdfData.numpages || 1,
        wordCount: countWords(cleaned)
      };
    } catch (err: any) {
      console.error(`PDF extraction error on ${originalFilename}:`, err);
      throw new Error(`Unable to extract readable text from this PDF resume: ${err.message || 'Corrupt or unreadable PDF'}`);
    }
  }

  if (normalizedType === 'docx' || normalizedType === 'doc') {
    try {
      const result = await mammoth.extractRawText({ buffer });
      const rawText = result.value || '';
      const cleaned = cleanExtractedText(rawText);

      if (!cleaned || cleaned.trim().length < 20) {
        throw new Error('Extracted DOCX text is too short or empty.');
      }

      return {
        text: cleaned,
        wordCount: countWords(cleaned)
      };
    } catch (err: any) {
      console.error(`DOCX extraction error on ${originalFilename}:`, err);
      throw new Error(`Unable to extract readable text from this DOCX resume: ${err.message || 'Corrupt or unreadable DOCX'}`);
    }
  }

  if (normalizedType === 'txt') {
    const rawText = buffer.toString('utf-8');
    const cleaned = cleanExtractedText(rawText);
    return {
      text: cleaned,
      wordCount: countWords(cleaned)
    };
  }

  throw new Error(`Unsupported file type: .${normalizedType}. Only PDF and DOCX files are supported.`);
}

/**
 * Normalizes unicode whitespace, removes non-printable binary artifacts,
 * and fixes erratic line breaks while preserving paragraph boundaries.
 */
export function cleanExtractedText(text: string): string {
  if (!text) return '';

  return text
    // Replace non-breaking spaces and exotic spaces with standard space
    .replace(/[\u00A0\u1680\u180E\u2000-\u200B\u202F\u205F\u3000\uFEFF]/g, ' ')
    // Replace weird bullet characters with standard dash
    .replace(/[•●▪■◦‣⁃]/g, '\n- ')
    // Replace carriage returns
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    // Remove null bytes and non-printable control chars except \n and \t
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '')
    // Collapse 3 or more blank lines into 2
    .replace(/\n{3,}/g, '\n\n')
    // Trim each line
    .split('\n')
    .map(line => line.trim())
    .join('\n')
    .trim();
}

function countWords(text: string): number {
  const tokens = text.match(/\b[A-Za-z0-9#+.]+\b/g);
  return tokens ? tokens.length : 0;
}

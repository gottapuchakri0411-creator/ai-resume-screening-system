import { db } from './db.js';
import { Job, Resume, Candidate, ScreeningResult } from './types.js';
import {
  matchSkills,
  computeCosineSimilarity,
  extractBasicContactInfo,
  extractSkillsFromText,
  normalizeSkill
} from './nlp.js';
import { analyzeResumeWithGemini, AIScreeningResult } from './ai.js';

export async function processAndScreenResume(
  job: Job,
  resume: Resume
): Promise<ScreeningResult> {
  const resumeText = resume.extractedText;
  if (!resumeText || resumeText.trim().length === 0) {
    throw new Error('Resume has no extracted text to screen.');
  }

  // 1. NLP Deterministic Processing
  const nlpSkillResult = matchSkills(resumeText, job.requiredSkills, job.preferredSkills);
  const cosineSim = computeCosineSimilarity(
    `${job.title} ${job.description} ${job.requiredSkills.join(' ')} ${job.preferredSkills.join(' ')}`,
    resumeText
  );
  const tfidfScore = Math.round(cosineSim * 100);

  // 2. Candidate Basic Extraction
  const basicInfo = extractBasicContactInfo(resumeText, resume.originalName);

  // 3. AI Semantic Analysis (Gemini 3.8 Flash)
  let aiResult: AIScreeningResult | null = null;
  let aiError: string | null = null;

  try {
    aiResult = await analyzeResumeWithGemini(
      job.title,
      job.description,
      job.requiredSkills,
      job.preferredSkills,
      job.minimumExperience,
      job.educationRequirements,
      resumeText,
      resume.originalName
    );
  } catch (err: any) {
    console.warn('Gemini AI screening failed or key not configured:', err.message);
    aiError = err.message;
  }

  // 4. Synthesize Scores and Metadata
  let finalMatchScore = 0;
  let finalSkillScore = nlpSkillResult.skillScore;
  let finalSemanticScore = tfidfScore;
  let finalExperienceScore = 50;
  let finalMatchedSkills: string[] = [];
  let finalMissingSkills: string[] = [];
  let relevantExperience = '';
  let educationRelevance = '';
  let satisfiedRequirements: string[] = [];
  let missingRequirements: string[] = [];
  let explanation = '';
  let status: ScreeningResult['status'] = 'Under Review';

  if (aiResult) {
    // Merge skills with AI findings
    const allMatched = Array.from(
      new Set([...nlpSkillResult.matchedSkills, ...aiResult.matchedSkills.map(s => normalizeSkill(s))])
    );
    // Keep missing strictly to skills truly missing from both
    const matchedSet = new Set(allMatched.map(s => s.toLowerCase()));
    const allMissing = job.requiredSkills
      .map(s => normalizeSkill(s))
      .filter(s => !matchedSet.has(s.toLowerCase()));

    finalMatchedSkills = allMatched;
    finalMissingSkills = allMissing;

    finalSemanticScore = aiResult.semanticScore;

    // Experience score heuristic
    const expRatio = basicInfo.experienceYears > 0 ? (basicInfo.experienceYears / (job.minimumExperience || 1)) : 0.8;
    finalExperienceScore = Math.min(100, Math.round(expRatio * 85));

    // Weighted Combined Score:
    // 40% Skills + 35% AI Semantic Understanding + 25% TF-IDF Keyword Match
    finalMatchScore = Math.min(
      100,
      Math.max(
        0,
        Math.round(
          finalSkillScore * 0.40 +
          finalSemanticScore * 0.35 +
          tfidfScore * 0.25
        )
      )
    );

    relevantExperience = aiResult.relevantExperience;
    educationRelevance = aiResult.educationRelevance;
    satisfiedRequirements = aiResult.satisfiedRequirements;
    missingRequirements = aiResult.missingRequirements;
    explanation = aiResult.explanation;
    status = aiResult.recommendedStatus;
  } else {
    // Pure Deterministic NLP fallback
    finalMatchedSkills = nlpSkillResult.matchedSkills;
    finalMissingSkills = nlpSkillResult.missingSkills;
    finalSemanticScore = tfidfScore;

    // Experience heuristic
    const expDiff = basicInfo.experienceYears >= job.minimumExperience;
    finalExperienceScore = expDiff ? 85 : 55;

    // 65% Skills Match + 35% TF-IDF Cosine Similarity
    finalMatchScore = Math.min(
      100,
      Math.max(
        0,
        Math.round(finalSkillScore * 0.65 + tfidfScore * 0.35)
      )
    );

    relevantExperience = basicInfo.experienceYears > 0
      ? `Resume indicates approximately ${basicInfo.experienceYears} years of experience (Role requires: ${job.minimumExperience} years).`
      : `Years of experience could not be definitively determined from text formatting.`;

    educationRelevance = basicInfo.education
      ? `Education identified in resume: ${basicInfo.education}.`
      : `No explicit degree match detected in automated header scan.`;

    satisfiedRequirements = [
      ...finalMatchedSkills.map(s => `Demonstrated skill: ${s}`),
      ...(basicInfo.experienceYears >= job.minimumExperience ? [`Meets minimum experience threshold (${job.minimumExperience} yrs)`] : [])
    ];

    missingRequirements = finalMissingSkills.map(s => `Missing required skill: ${s}`);

    explanation = `Automated NLP screening evaluated ${finalMatchedSkills.length} matched skills against job requirements. Keyword and content cosine similarity: ${tfidfScore}%. Note: Standard NLP algorithm was used (${aiError || 'AI semantic model offline'}).`;

    if (finalMatchScore >= 80) status = 'Shortlisted';
    else if (finalMatchScore >= 60) status = 'Under Review';
    else if (finalMatchScore >= 45) status = 'Reviewed';
    else status = 'Rejected';
  }

  // 5. Update or Create Candidate Record
  let candidate = db.getCandidateById(resume.candidateId);
  const candidateName = aiResult?.candidateName || basicInfo.candidateName;
  const email = aiResult?.email || basicInfo.email;
  const phone = aiResult?.phone || basicInfo.phone;
  const education = aiResult?.educationSummary || basicInfo.education;
  const experienceYears = aiResult?.experienceYears || basicInfo.experienceYears;

  if (candidate) {
    db.updateCandidate(candidate.id, {
      name: candidateName,
      email: email || candidate.email,
      phone: phone || candidate.phone,
      education: education || candidate.education,
      experienceYears: experienceYears || candidate.experienceYears,
      extractedSkills: Array.from(new Set([...(candidate.extractedSkills || []), ...finalMatchedSkills]))
    });
  } else {
    candidate = db.createCandidate({
      id: resume.candidateId,
      recruiterId: job.recruiterId,
      name: candidateName,
      email,
      phone,
      education,
      experienceYears,
      extractedSkills: finalMatchedSkills,
      createdAt: new Date().toISOString()
    });
  }

  // 6. Save or Update ScreeningResult
  const screeningResult: ScreeningResult = {
    id: `screen_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    jobId: job.id,
    candidateId: candidate.id,
    resumeId: resume.id,
    matchScore: finalMatchScore,
    skillScore: finalSkillScore,
    semanticScore: finalSemanticScore,
    experienceScore: finalExperienceScore,
    matchedSkills: finalMatchedSkills,
    missingSkills: finalMissingSkills,
    relevantExperience,
    educationRelevance,
    satisfiedRequirements,
    missingRequirements,
    explanation,
    status,
    screenedAt: new Date().toISOString()
  };

  db.saveScreeningResult(screeningResult);

  // 7. Mark Resume as Processed
  db.updateResume(resume.id, {
    processingStatus: 'Processed',
    failureReason: undefined
  });

  return screeningResult;
}

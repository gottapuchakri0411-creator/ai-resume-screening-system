export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  company: string;
  role: string;
  createdAt: string;
}

export interface Job {
  id: string;
  recruiterId: string;
  title: string;
  company: string;
  department: string;
  location: string;
  employmentType: 'Full-time' | 'Part-time' | 'Contract' | 'Remote' | 'Internship';
  description: string;
  requiredSkills: string[];
  preferredSkills: string[];
  minimumExperience: number; // in years
  educationRequirements: string;
  status: 'Active' | 'Closed' | 'Draft';
  createdAt: string;
  updatedAt: string;
}

export interface Candidate {
  id: string;
  recruiterId: string;
  name: string;
  email?: string;
  phone?: string;
  location?: string;
  extractedSkills: string[];
  experienceYears: number;
  education?: string;
  summary?: string;
  createdAt: string;
}

export interface Resume {
  id: string;
  candidateId: string;
  jobId: string;
  filename: string;
  originalName: string;
  fileType: 'pdf' | 'docx' | 'txt';
  fileSize: number;
  extractedText: string;
  processingStatus: 'Uploaded' | 'Processing' | 'Processed' | 'Failed';
  failureReason?: string;
  uploadedAt: string;
}

export interface ScreeningResult {
  id: string;
  jobId: string;
  candidateId: string;
  resumeId: string;
  matchScore: number; // 0 - 100
  skillScore: number;
  semanticScore: number;
  experienceScore: number;
  matchedSkills: string[];
  missingSkills: string[];
  relevantExperience: string;
  educationRelevance: string;
  satisfiedRequirements: string[];
  missingRequirements: string[];
  explanation: string;
  status: 'Shortlisted' | 'Under Review' | 'Reviewed' | 'Rejected';
  screenedAt: string;
}

export interface CandidateNote {
  id: string;
  candidateId: string;
  jobId?: string;
  recruiterId: string;
  recruiterName: string;
  content: string;
  createdAt: string;
  updatedAt: string;
}

export interface AppDatabase {
  users: User[];
  jobs: Job[];
  candidates: Candidate[];
  resumes: Resume[];
  screeningResults: ScreeningResult[];
  notes: CandidateNote[];
}

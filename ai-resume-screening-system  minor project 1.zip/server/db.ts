import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { AppDatabase, User, Job, Candidate, Resume, ScreeningResult, CandidateNote } from './types.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const UPLOAD_DIR = path.resolve(process.cwd(), 'uploads');
const DB_FILE = path.join(DATA_DIR, 'database.json');

// Ensure directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

const defaultDatabase: AppDatabase = {
  users: [],
  jobs: [],
  candidates: [],
  resumes: [],
  screeningResults: [],
  notes: []
};

class DatabaseStore {
  private db: AppDatabase;

  constructor() {
    this.db = this.loadDatabase();
    this.seedDefaultsIfEmpty();
  }

  private loadDatabase(): AppDatabase {
    try {
      if (fs.existsSync(DB_FILE)) {
        const content = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(content);
      }
    } catch (err) {
      console.error('Error reading database file, initializing clean database:', err);
    }
    return JSON.parse(JSON.stringify(defaultDatabase));
  }

  public save(): void {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.db, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to write database file:', err);
    }
  }

  private seedDefaultsIfEmpty(): void {
    if (this.db.users.length === 0) {
      const salt = bcrypt.genSaltSync(10);
      const passwordHash = bcrypt.hashSync('Password123!', salt);

      const defaultUser: User = {
        id: 'usr_recruiter_01',
        name: 'Sarah Jenkins',
        email: 'recruiter@talentai.com',
        passwordHash,
        company: 'Apex Tech Solutions',
        role: 'Senior Talent Acquisition Lead',
        createdAt: new Date().toISOString()
      };
      this.db.users.push(defaultUser);

      // Seed initial representative jobs
      const job1: Job = {
        id: 'job_senior_fullstack_01',
        recruiterId: defaultUser.id,
        title: 'Senior Full Stack Engineer',
        company: 'Apex Tech Solutions',
        department: 'Engineering',
        location: 'San Francisco, CA (Hybrid)',
        employmentType: 'Full-time',
        description: 'We are seeking a seasoned Senior Full Stack Engineer to lead the architecture and development of scalable web applications. You will be designing robust microservices, crafting responsive React interfaces, and mentoring junior engineers. Experience with modern cloud architectures, CI/CD pipelines, and high-performance databases is essential.',
        requiredSkills: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Docker', 'REST API'],
        preferredSkills: ['GraphQL', 'AWS', 'Kubernetes', 'Redis', 'Tailwind CSS'],
        minimumExperience: 5,
        educationRequirements: "Bachelor's degree in Computer Science or equivalent practical experience",
        status: 'Active',
        createdAt: new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString(),
        updatedAt: new Date(Date.now() - 7 * 24 * 3600 * 1000).toISOString()
      };

      const job2: Job = {
        id: 'job_ai_ml_02',
        recruiterId: defaultUser.id,
        title: 'AI / Machine Learning Engineer',
        company: 'Apex Tech Solutions',
        department: 'Data & AI',
        location: 'Remote',
        employmentType: 'Full-time',
        description: 'Join our cutting-edge AI team to build, fine-tune, and deploy state-of-the-art NLP and Large Language Model applications. You will collaborate with product teams to build semantic search systems, retrieval-augmented generation pipelines, and automated text evaluation frameworks.',
        requiredSkills: ['Python', 'PyTorch', 'Machine Learning', 'NLP', 'FastAPI', 'SQL'],
        preferredSkills: ['Transformers', 'Vector Databases', 'Docker', 'LangChain', 'MLOps'],
        minimumExperience: 3,
        educationRequirements: "Master's or Bachelor's in CS, AI, Data Science, or related quantitative field",
        status: 'Active',
        createdAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
        updatedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString()
      };

      this.db.jobs.push(job1, job2);

      // Seed candidates for Job 1
      const cand1: Candidate = {
        id: 'cand_alex_chen_01',
        recruiterId: defaultUser.id,
        name: 'Alex Chen',
        email: 'alex.chen.dev@example.com',
        phone: '+1 (555) 234-5678',
        location: 'San Francisco, CA',
        extractedSkills: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Docker', 'GraphQL', 'AWS', 'Tailwind CSS', 'Next.js'],
        experienceYears: 6,
        education: 'B.S. in Computer Science, University of California, Berkeley',
        summary: 'Senior Full Stack Engineer with 6 years of experience building scalable SaaS products, distributed systems, and real-time dashboards.',
        createdAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString()
      };

      const resume1: Resume = {
        id: 'res_alex_chen_01',
        candidateId: cand1.id,
        jobId: job1.id,
        filename: 'Alex_Chen_Senior_FullStack_Resume.pdf',
        originalName: 'Alex_Chen_Senior_FullStack_Resume.pdf',
        fileType: 'pdf',
        fileSize: 142800,
        extractedText: `ALEX CHEN
Email: alex.chen.dev@example.com | Phone: +1 (555) 234-5678 | San Francisco, CA
LinkedIn: linkedin.com/in/alexchen-dev | GitHub: github.com/alexchen

PROFESSIONAL SUMMARY
Senior Full Stack Engineer with 6 years of hands-on experience designing and building high-traffic enterprise web platforms. Deep expertise in React, TypeScript, Node.js, PostgreSQL, and cloud deployments on AWS with Docker.

CORE SKILLS
Languages: TypeScript, JavaScript, SQL, Python, HTML5, CSS3
Frontend: React, Next.js, Redux Toolkit, Tailwind CSS, Vite
Backend: Node.js, Express, REST API, GraphQL, Microservices
Databases: PostgreSQL, Redis, MongoDB
DevOps & Cloud: Docker, AWS (ECS, S3, CloudFront), CI/CD (GitHub Actions)

PROFESSIONAL EXPERIENCE
Senior Software Engineer | CloudScale Systems (2022 – Present)
- Led a team of 4 engineers rebuilding core analytics dashboard using React, TypeScript, and Tailwind CSS, improving page load speeds by 42%.
- Engineered Node.js microservices handling 25,000+ API requests per second with PostgreSQL and Redis caching.
- Spearheaded containerization of all frontend and backend services using Docker, accelerating CI/CD pipeline deployments.

Software Engineer | Nova Interactive (2018 – 2022)
- Designed full-stack features utilizing React and Node.js REST APIs for an e-commerce platform with 500k monthly active users.
- Optimized complex PostgreSQL database queries and indexing strategies, decreasing query latency by 35%.
- Integrated AWS services (S3 for document storage, CloudWatch for error monitoring).

EDUCATION
Bachelor of Science in Computer Science | University of California, Berkeley (2014 – 2018)`,
        processingStatus: 'Processed',
        uploadedAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString()
      };

      const screeningResult1: ScreeningResult = {
        id: 'screen_alex_chen_01',
        jobId: job1.id,
        candidateId: cand1.id,
        resumeId: resume1.id,
        matchScore: 92,
        skillScore: 95,
        semanticScore: 90,
        experienceScore: 92,
        matchedSkills: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Docker', 'REST API', 'GraphQL', 'AWS', 'Tailwind CSS'],
        missingSkills: ['Kubernetes'],
        relevantExperience: '6 years of full-stack engineering exceeding the 5-year minimum requirement, with proven leadership in React, Node.js, and PostgreSQL architectures.',
        educationRelevance: 'B.S. in Computer Science from UC Berkeley directly satisfies the education requirement.',
        satisfiedRequirements: [
          '5+ years full-stack development experience',
          'Proficiency with React and TypeScript',
          'Backend experience with Node.js and REST APIs',
          'Relational database expertise with PostgreSQL',
          'Containerization with Docker'
        ],
        missingRequirements: [
          'Kubernetes cluster management experience'
        ],
        explanation: 'Alex Chen demonstrates an exceptional match for the Senior Full Stack Engineer role. He possesses almost all required and preferred skills, including React, TypeScript, Node.js, PostgreSQL, Docker, and AWS. His 6 years of experience exceed the role threshold, and his project achievements show direct alignment with our engineering goals.',
        status: 'Shortlisted',
        screenedAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString()
      };

      const cand2: Candidate = {
        id: 'cand_marcus_vance_02',
        recruiterId: defaultUser.id,
        name: 'Marcus Vance',
        email: 'marcus.vance@mailtech.io',
        phone: '+1 (555) 876-5432',
        location: 'Austin, TX',
        extractedSkills: ['React', 'JavaScript', 'HTML5', 'CSS3', 'REST API', 'PostgreSQL'],
        experienceYears: 3,
        education: 'B.A. in Information Systems, Texas State University',
        summary: 'Frontend-leaning software engineer with 3 years of experience developing responsive web applications and REST APIs.',
        createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString()
      };

      const resume2: Resume = {
        id: 'res_marcus_vance_02',
        candidateId: cand2.id,
        jobId: job1.id,
        filename: 'Marcus_Vance_Resume.docx',
        originalName: 'Marcus_Vance_Resume.docx',
        fileType: 'docx',
        fileSize: 98400,
        extractedText: `MARCUS VANCE
marcus.vance@mailtech.io | (555) 876-5432 | Austin, TX

SUMMARY
Software Engineer with 3 years of experience specializing in client-side web development with React and JavaScript, integrated with RESTful APIs.

SKILLS
- Languages: JavaScript (ES6+), HTML5, CSS3, SQL
- Frameworks & Tools: React, Vite, Bootstrap, Git, Express
- Databases: PostgreSQL, SQLite

EXPERIENCE
Frontend Developer | WebCraft Digital (2021 – Present)
- Developed customer-facing React components for client portals.
- Integrated REST APIs with backend services written in Express.js.
- Maintained PostgreSQL database tables and basic CRUD queries.

EDUCATION
B.A. in Information Systems | Texas State University (2017 – 2021)`,
        processingStatus: 'Processed',
        uploadedAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString()
      };

      const screeningResult2: ScreeningResult = {
        id: 'screen_marcus_vance_02',
        jobId: job1.id,
        candidateId: cand2.id,
        resumeId: resume2.id,
        matchScore: 64,
        skillScore: 60,
        semanticScore: 68,
        experienceScore: 62,
        matchedSkills: ['React', 'REST API', 'PostgreSQL'],
        missingSkills: ['TypeScript', 'Docker', 'Node.js', 'Kubernetes', 'AWS'],
        relevantExperience: '3 years of experience as a software developer, which is below the 5-year requirement for a Senior role.',
        educationRelevance: 'B.A. in Information Systems meets general educational requirements.',
        satisfiedRequirements: [
          'Experience building React web applications',
          'Working knowledge of REST APIs and PostgreSQL'
        ],
        missingRequirements: [
          '5+ years minimum experience (candidate has 3 years)',
          'TypeScript production experience not demonstrated',
          'Docker containerization not found',
          'Cloud infrastructure / AWS experience not evidenced'
        ],
        explanation: 'Marcus Vance shows solid frontend competence with React and basic SQL knowledge, but lacks senior-level tenure (3 years vs 5 required) and key required competencies including TypeScript and Docker containerization.',
        status: 'Under Review',
        screenedAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString()
      };

      const note1: CandidateNote = {
        id: 'note_alex_01',
        candidateId: cand1.id,
        jobId: job1.id,
        recruiterId: defaultUser.id,
        recruiterName: defaultUser.name,
        content: 'Impressive track record at CloudScale. Strong React and Docker experience. Scheduled for preliminary phone screen next Tuesday.',
        createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
        updatedAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString()
      };

      this.db.candidates.push(cand1, cand2);
      this.db.resumes.push(resume1, resume2);
      this.db.screeningResults.push(screeningResult1, screeningResult2);
      this.db.notes.push(note1);

      this.save();
    }
  }

  // User Methods
  public findUserByEmail(email: string): User | undefined {
    return this.db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public findUserById(id: string): User | undefined {
    return this.db.users.find(u => u.id === id);
  }

  public createUser(user: User): User {
    this.db.users.push(user);
    this.save();
    return user;
  }

  // Job Methods
  public getJobs(recruiterId?: string): Job[] {
    if (recruiterId) {
      return this.db.jobs.filter(j => j.recruiterId === recruiterId);
    }
    return this.db.jobs;
  }

  public getJobById(id: string): Job | undefined {
    return this.db.jobs.find(j => j.id === id);
  }

  public createJob(job: Job): Job {
    this.db.jobs.unshift(job);
    this.save();
    return job;
  }

  public updateJob(id: string, updates: Partial<Job>): Job | undefined {
    const index = this.db.jobs.findIndex(j => j.id === id);
    if (index === -1) return undefined;
    this.db.jobs[index] = {
      ...this.db.jobs[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    this.save();
    return this.db.jobs[index];
  }

  public deleteJob(id: string): boolean {
    const initialLen = this.db.jobs.length;
    this.db.jobs = this.db.jobs.filter(j => j.id !== id);
    if (this.db.jobs.length !== initialLen) {
      // Cascade delete resumes & screening results for this job
      this.db.resumes = this.db.resumes.filter(r => r.jobId !== id);
      this.db.screeningResults = this.db.screeningResults.filter(s => s.jobId !== id);
      this.save();
      return true;
    }
    return false;
  }

  // Candidate Methods
  public getCandidates(recruiterId?: string): Candidate[] {
    if (recruiterId) {
      return this.db.candidates.filter(c => c.recruiterId === recruiterId);
    }
    return this.db.candidates;
  }

  public getCandidateById(id: string): Candidate | undefined {
    return this.db.candidates.find(c => c.id === id);
  }

  public createCandidate(candidate: Candidate): Candidate {
    this.db.candidates.unshift(candidate);
    this.save();
    return candidate;
  }

  public updateCandidate(id: string, updates: Partial<Candidate>): Candidate | undefined {
    const index = this.db.candidates.findIndex(c => c.id === id);
    if (index === -1) return undefined;
    this.db.candidates[index] = { ...this.db.candidates[index], ...updates };
    this.save();
    return this.db.candidates[index];
  }

  // Resume Methods
  public getResumesByJob(jobId: string): Resume[] {
    return this.db.resumes.filter(r => r.jobId === jobId);
  }

  public getResumeById(id: string): Resume | undefined {
    return this.db.resumes.find(r => r.id === id);
  }

  public createResume(resume: Resume): Resume {
    this.db.resumes.unshift(resume);
    this.save();
    return resume;
  }

  public updateResume(id: string, updates: Partial<Resume>): Resume | undefined {
    const index = this.db.resumes.findIndex(r => r.id === id);
    if (index === -1) return undefined;
    this.db.resumes[index] = { ...this.db.resumes[index], ...updates };
    this.save();
    return this.db.resumes[index];
  }

  public deleteResume(id: string): boolean {
    const resume = this.db.resumes.find(r => r.id === id);
    if (!resume) return false;
    this.db.resumes = this.db.resumes.filter(r => r.id !== id);
    this.db.screeningResults = this.db.screeningResults.filter(s => s.resumeId !== id);
    this.save();
    return true;
  }

  // Screening Result Methods
  public getScreeningResultsByJob(jobId: string): ScreeningResult[] {
    return this.db.screeningResults.filter(s => s.jobId === jobId);
  }

  public getScreeningResultByCandidate(candidateId: string): ScreeningResult | undefined {
    return this.db.screeningResults.find(s => s.candidateId === candidateId);
  }

  public getScreeningResultById(id: string): ScreeningResult | undefined {
    return this.db.screeningResults.find(s => s.id === id);
  }

  public saveScreeningResult(result: ScreeningResult): ScreeningResult {
    const index = this.db.screeningResults.findIndex(s => s.id === result.id || (s.jobId === result.jobId && s.candidateId === result.candidateId));
    if (index >= 0) {
      this.db.screeningResults[index] = result;
    } else {
      this.db.screeningResults.unshift(result);
    }
    this.save();
    return result;
  }

  public updateScreeningResultStatus(id: string, status: ScreeningResult['status']): ScreeningResult | undefined {
    const item = this.db.screeningResults.find(s => s.id === id);
    if (item) {
      item.status = status;
      this.save();
    }
    return item;
  }

  // Notes Methods
  public getNotesByCandidate(candidateId: string): CandidateNote[] {
    return this.db.notes.filter(n => n.candidateId === candidateId).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public createNote(note: CandidateNote): CandidateNote {
    this.db.notes.unshift(note);
    this.save();
    return note;
  }

  public updateNote(id: string, content: string): CandidateNote | undefined {
    const note = this.db.notes.find(n => n.id === id);
    if (note) {
      note.content = content;
      note.updatedAt = new Date().toISOString();
      this.save();
    }
    return note;
  }

  public deleteNote(id: string): boolean {
    const initialLen = this.db.notes.length;
    this.db.notes = this.db.notes.filter(n => n.id !== id);
    if (this.db.notes.length !== initialLen) {
      this.save();
      return true;
    }
    return false;
  }

  // Analytics Aggregation
  public getAnalytics(recruiterId?: string) {
    const jobs = this.getJobs(recruiterId);
    const jobIds = new Set(jobs.map(j => j.id));
    const resumes = this.db.resumes.filter(r => jobIds.has(r.jobId));
    const candidates = this.getCandidates(recruiterId);
    const screening = this.db.screeningResults.filter(s => jobIds.has(s.jobId));

    const totalJobs = jobs.length;
    const activeJobs = jobs.filter(j => j.status === 'Active').length;
    const totalResumes = resumes.length;
    const processedResumes = resumes.filter(r => r.processingStatus === 'Processed').length;
    const totalCandidates = candidates.length;
    const candidatesRequiringReview = screening.filter(s => s.status === 'Under Review').length;

    const scores = screening.map(s => s.matchScore);
    const averageMatchScore = scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;

    // Score distribution buckets
    const scoreDistribution = [
      { range: '90-100%', count: screening.filter(s => s.matchScore >= 90).length },
      { range: '80-89%', count: screening.filter(s => s.matchScore >= 80 && s.matchScore < 90).length },
      { range: '70-79%', count: screening.filter(s => s.matchScore >= 70 && s.matchScore < 80).length },
      { range: '60-69%', count: screening.filter(s => s.matchScore >= 60 && s.matchScore < 70).length },
      { range: '<60%', count: screening.filter(s => s.matchScore < 60).length },
    ];

    // Candidates per job
    const candidatesPerJob = jobs.map(j => {
      const count = screening.filter(s => s.jobId === j.id).length;
      return {
        jobTitle: j.title.length > 20 ? j.title.slice(0, 18) + '...' : j.title,
        count
      };
    });

    // Skill frequencies
    const skillCounts: Record<string, number> = {};
    const missingSkillCounts: Record<string, number> = {};

    screening.forEach(s => {
      s.matchedSkills.forEach(skill => {
        skillCounts[skill] = (skillCounts[skill] || 0) + 1;
      });
      s.missingSkills.forEach(skill => {
        missingSkillCounts[skill] = (missingSkillCounts[skill] || 0) + 1;
      });
    });

    const topSkills = Object.entries(skillCounts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);

    const topMissingSkills = Object.entries(missingSkillCounts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);

    return {
      totalJobs,
      activeJobs,
      totalResumes,
      processedResumes,
      totalCandidates,
      candidatesRequiringReview,
      averageMatchScore,
      scoreDistribution,
      candidatesPerJob,
      topSkills,
      topMissingSkills,
      recentScreenings: screening.slice(0, 5)
    };
  }
}

export const db = new DatabaseStore();
